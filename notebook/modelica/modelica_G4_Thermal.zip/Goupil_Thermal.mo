package Goupil_Thermal

  package Mechanical_Components
    model Goupil
      parameter Modelica.SIunits.Mass GoupilMass = 1300 "Total mass with load and driver ";
      parameter Real Crr = 1e-2 "Rolling coeficient";
      parameter Real Alpha = 0.5061 "Aerodynamic coefficient";
      constant Modelica.SIunits.Acceleration g = Modelica.Constants.g_n "Gravity constant";
      Modelica.Mechanics.Translational.Components.Mass mass(m=GoupilMass, v(fixed=
              true, start=v_init))                                           annotation (
        Placement(transformation(extent = {{34, 50}, {54, 70}})));
      Modelica.Mechanics.Translational.Components.SupportFriction RollingFriction(f_pos=[0,
            GoupilMass*g*Crr])                                                                                        annotation (
        Placement(transformation(extent={{-44,50},{-24,70}})));
      Modelica.Mechanics.Translational.Sources.Force force annotation (
        Placement(transformation(extent = {{-10, -10}, {10, 10}}, rotation = 90, origin={34,26})));
      Modelica.Mechanics.Translational.Sensors.SpeedSensor speedSensor annotation (
        Placement(transformation(extent={{66,50},{86,70}})));
      Modelica.Blocks.Math.Atan atan annotation (
        Placement(transformation(extent={{-66,-90},{-46,-70}})));
      Modelica.Blocks.Math.Gain GainSlopeForce(k=-GoupilMass*g)      annotation (
        Placement(transformation(extent={{-2,-90},{18,-70}})));
      Modelica.Blocks.Math.Sin sin annotation (
        Placement(transformation(extent={{-36,-90},{-16,-70}})));
      Modelica.Blocks.Interfaces.RealInput Slope "Slope " annotation (
        Placement(transformation(extent = {{-120, -100}, {-80, -60}}), iconTransformation(extent = {{-20, -20}, {20, 20}}, rotation = 90, origin = {0, -76})));
      Modelica.Mechanics.Translational.Interfaces.Flange_a flange_a "Flange of left shaft" annotation (
        Placement(transformation(extent = {{-110, -40}, {-90, -20}}), iconTransformation(extent = {{-110, -40}, {-90, -20}})));
      Modelica.Mechanics.Translational.Sources.QuadraticSpeedDependentForce
        quadraticSpeedDependentForce(f_nominal=-Alpha, v_nominal=1)
        annotation (Placement(transformation(extent={{-2,76},{18,96}})));
      parameter Modelica.SIunits.Velocity v_init=0 "Initial speed";
    equation
      connect(RollingFriction.flange_b, mass.flange_a) annotation (
        Line(points={{-24,60},{34,60}},     color = {0, 127, 0}, smooth = Smooth.None));
      connect(mass.flange_b, speedSensor.flange) annotation (
        Line(points={{54,60},{66,60}},      color = {0, 127, 0}, smooth = Smooth.None));
      connect(force.flange, mass.flange_a) annotation (
        Line(points={{34,36},{34,60}},      color = {0, 127, 0}, smooth = Smooth.None));
      connect(sin.y, GainSlopeForce.u) annotation (
        Line(points={{-15,-80},{-4,-80}},       color = {0, 0, 127}, smooth = Smooth.None));
      connect(sin.u, atan.y) annotation (
        Line(points={{-38,-80},{-45,-80}},      color = {0, 0, 127}, smooth = Smooth.None));
      connect(atan.u, Slope) annotation (
        Line(points={{-68,-80},{-100,-80}},                              color = {0, 0, 127}, smooth = Smooth.None));
      connect(RollingFriction.flange_a, flange_a) annotation (
        Line(points={{-44,60},{-98,60},{-98,-30},{-100,-30}},        color = {0, 127, 0}, smooth = Smooth.None));
      connect(GainSlopeForce.y, force.f)
        annotation (Line(points={{19,-80},{34,-80},{34,14}}, color={0,0,127}));
      connect(quadraticSpeedDependentForce.flange, mass.flange_a)
        annotation (Line(points={{18,86},{34,86},{34,60}}, color={0,127,0}));
      annotation (Icon(graphics={
            Line(
              points={{100,-32},{-100,-56},{100,-56}},
              color={0,0,0},
              smooth=Smooth.None),
            Ellipse(
              extent={{-60,-18},{-28,-50}},
              lineColor={0,0,0},
              fillColor={0,0,0},
              fillPattern=FillPattern.Solid),
            Line(
              points={{-92,-30},{-56,-30},{-60,-40}},
              color={0,0,0},
              smooth=Smooth.None),
            Text(
              extent={{20,-64},{84,-86}},
              lineColor={0,0,0},
              fillColor={0,0,0},
              fillPattern=FillPattern.Solid,
              textString="Slope"),
            Line(points={{-60,-26}}, color={28,108,200}),
            Ellipse(
              extent={{42,-6},{74,-38}},
              lineColor={0,0,0},
              fillColor={0,0,0},
              fillPattern=FillPattern.Solid),
            Polygon(
              points={{-68,-30},{82,-10},{78,14},{72,28},{60,36},{46,42},{24,40},{30,
                  0},{-70,-14},{-68,-30}},
              lineColor={28,108,200},
              fillColor={0,0,0},
              fillPattern=FillPattern.Solid),
            Line(points={{-68,-30},{84,-10}}, color={255,255,255}),
            Polygon(
              points={{30,36},{34,10},{44,12},{54,14},{72,16},{68,26},{60,32},{46,38},
                  {30,36}},
              lineColor={255,255,255},
              fillColor={255,255,255},
              fillPattern=FillPattern.Solid)}));
    end Goupil;

    model TestGoupil
      Mechanical_Components.Goupil goupil_AeroSimple
        annotation (Placement(transformation(extent={{24,12},{56,46}})));
      Modelica.Blocks.Sources.Step stepForce1(height=1053.21) annotation (
        Placement(transformation(extent={{-72,14},{-52,34}})));
      Modelica.Blocks.Sources.Step stepSlope1(height=0.07) annotation (
        Placement(transformation(extent={{8,-22},{28,-2}})));
      Modelica.Mechanics.Translational.Sources.Force force1
                                                           annotation (
        Placement(visible = true, transformation(extent={{-22,14},{-2,34}},       rotation = 0)));
    equation
      connect(force1.flange,goupil_AeroSimple. flange_a) annotation (Line(points={{-2,24},
              {19,24},{19,23.9},{24,23.9}},              color={0,127,0}));
      connect(stepForce1.y,force1. f)
        annotation (Line(points={{-51,24},{-24,24}}, color={0,0,127}));
      connect(stepSlope1.y,goupil_AeroSimple. Slope) annotation (Line(points={{29,-12},
              {40,-12},{40,16.08}},       color={0,0,127}));
      annotation (         experiment(StopTime=300));
    end TestGoupil;

    model TestSlopeMotor
      Modelica.Blocks.Sources.Step stepTorque(height=23.26)  annotation (
        Placement(transformation(extent={{-162,48},{-142,68}})));
      Modelica.Blocks.Sources.Step stepSlope(height=0.07)  annotation (
        Placement(transformation(extent={{100,16},{120,36}})));
      Modelica.Mechanics.Translational.Components.IdealRollingWheel WheelGoupil(radius=
            0.289)
        annotation (Placement(transformation(extent={{82,48},{102,68}})));
      Modelica.Mechanics.Rotational.Components.LossyGear ReducerAndDifferential(lossTable=
           [0,0.88,0.88,0,0], ratio=14.87)
        annotation (Placement(transformation(extent={{-18,48},{2,68}})));
      Modelica.Mechanics.Rotational.Components.Inertia inertiaReducerMotor(J=0.57e-4)            annotation (
        Placement(transformation(extent={{-50,48},{-30,68}})));
      Modelica.Mechanics.Rotational.Sources.Torque torque annotation (
        Placement(transformation(extent={{-120,48},{-100,68}})));
      Modelica.Mechanics.Rotational.Sensors.PowerSensor powerSensor annotation (
        Placement(transformation(extent={{-86,48},{-66,68}})));
      Modelica.Mechanics.Rotational.Sensors.PowerSensor powerSensor1 annotation (
        Placement(transformation(extent={{16,48},{36,68}})));
      Modelica.Mechanics.Rotational.Components.Inertia inertiaWheels(J=1.68)
        annotation (Placement(transformation(extent={{48,48},{68,68}})));
      Modelica.Blocks.Sources.Step stepTorque1(height=23.26) annotation (
        Placement(transformation(extent={{-162,-30},{-142,-10}})));
      Modelica.Blocks.Sources.Step stepSlope1(height=0.07) annotation (
        Placement(transformation(extent={{104,-64},{124,-44}})));
      Modelica.Mechanics.Translational.Components.IdealRollingWheel WheelGoupil1(radius=
            0.289)
        annotation (Placement(transformation(extent={{86,-30},{106,-10}})));
      Modelica.Mechanics.Rotational.Components.LossyGear ReducerAndDifferential1(lossTable=
           [0,0.88,0.88,0,0], ratio=14.87)
        annotation (Placement(transformation(extent={{-14,-30},{6,-10}})));
      Modelica.Mechanics.Rotational.Sources.Torque torque1
                                                          annotation (
        Placement(transformation(extent={{-116,-30},{-96,-10}})));
      Modelica.Mechanics.Rotational.Sensors.PowerSensor powerSensor2
                                                                    annotation (
        Placement(transformation(extent={{-82,-30},{-62,-10}})));
      Modelica.Mechanics.Rotational.Sensors.PowerSensor powerSensor3 annotation (
        Placement(transformation(extent={{20,-30},{40,-10}})));
      Mechanical_Components.Goupil goupil
        annotation (Placement(transformation(extent={{114,48},{140,74}})));
      Mechanical_Components.Goupil goupil1
        annotation (Placement(transformation(extent={{116,-28},{142,-2}})));
    equation
      connect(stepSlope.y, goupil.Slope) annotation (Line(points={{121,26},{127,
              26},{127,51.12}},  color={0,0,127}));
      connect(inertiaReducerMotor.flange_b, ReducerAndDifferential.flange_a)
        annotation (Line(points={{-30,58},{-18,58}}));
      connect(ReducerAndDifferential.flange_b, powerSensor1.flange_a)
        annotation (Line(points={{2,58},{16,58}}));
      connect(torque.tau, stepTorque.y) annotation (
        Line(points={{-122,58},{-141,58}},  color = {0, 0, 127}));
      connect(torque.flange, powerSensor.flange_a) annotation (
        Line(points={{-100,58},{-86,58}}));
      connect(powerSensor.flange_b, inertiaReducerMotor.flange_a) annotation (
        Line(points={{-66,58},{-50,58}}));
      connect(powerSensor1.flange_b, inertiaWheels.flange_a)
        annotation (Line(points={{36,58},{48,58}},
                                                 color={0,0,0}));
      connect(WheelGoupil.flangeR, inertiaWheels.flange_b)
        annotation (Line(points={{82,58},{68,58}},
                                                 color={0,0,0}));
      connect(ReducerAndDifferential1.flange_b, powerSensor3.flange_a)
        annotation (Line(points={{6,-20},{20,-20}}));
      connect(torque1.tau, stepTorque1.y)
        annotation (Line(points={{-118,-20},{-141,-20}}, color={0,0,127}));
      connect(torque1.flange, powerSensor2.flange_a)
        annotation (Line(points={{-96,-20},{-82,-20}}));
      connect(powerSensor3.flange_b, WheelGoupil1.flangeR)
        annotation (Line(points={{40,-20},{86,-20}}, color={0,0,0}));
      connect(powerSensor2.flange_b, ReducerAndDifferential1.flange_a)
        annotation (Line(points={{-62,-20},{-14,-20}}, color={0,0,0}));
      connect(goupil.flange_a, WheelGoupil.flangeT) annotation (Line(points={{114,
              57.1},{112,57.1},{112,58},{102,58}}, color={0,127,0}));
      connect(goupil1.flange_a, WheelGoupil1.flangeT) annotation (Line(points={{
              116,-18.9},{114,-18.9},{114,-20},{106,-20}}, color={0,127,0}));
      connect(stepSlope1.y, goupil1.Slope) annotation (Line(points={{125,-54},{
              129,-54},{129,-24.88}}, color={0,0,127}));
      annotation (
        Diagram(coordinateSystem(preserveAspectRatio = true, extent={{-180,-100},
                {150,100}})),
        Icon(coordinateSystem(preserveAspectRatio = true, extent={{-180,-100},{
                150,100}})));
    end TestSlopeMotor;
  end Mechanical_Components;

  package Electrical_Components
    model DCDCconverter "Gyrator"
      extends Modelica.Electrical.Analog.Interfaces.TwoPort;
      Modelica.Blocks.Interfaces.RealInput Alpha annotation (Placement(
            transformation(extent={{-18,-100},{22,-60}}), iconTransformation(
            extent={{-20,-20},{20,20}},
            rotation=90,
            origin={0,-80})));
    equation
      v2 = Alpha*v1;
      i1 = -Alpha*i2;
      annotation (
        Documentation(info="<html>
<p>A gyrator is a two-port element defined by the following equations:</p>
<pre>    i1 =  G2 * v2
    i2 = -G1 * v1</pre>
<p>where the constants <em>G1</em>, <em>G2</em> are called the gyration conductance.</p>
</html>",   revisions="<html>
<ul>
<li><em> 1998   </em>
       by Christoph Clauss<br> initially implemented<br>
       </li>
</ul>
</html>"),
        Icon(coordinateSystem(preserveAspectRatio=true, extent={{-100,-100},{100,
                100}}), graphics={
            Rectangle(
              extent={{-80,80},{80,-80}},
              fillColor={255,255,255},
              fillPattern=FillPattern.Solid,
              lineColor={0,0,255}),
            Text(
              extent={{-150,151},{150,111}},
              textString="%name",
              lineColor={0,0,255}),
            Line(points={{-100,100},{-40,100},{-40,80}}, color={0,0,255}),
            Line(
              points={{20,25},{-40,25},{-40,5}},
              color={0,0,255},
              origin={80,75},
              rotation=360),
            Line(
              points={{-35,-20},{25,-20},{25,0}},
              color={0,0,255},
              origin={-65,-80},
              rotation=360),
            Line(
              points={{20,-25},{-40,-25},{-40,-5}},
              color={0,0,255},
              origin={80,-75},
              rotation=360),
            Line(points={{80,80},{-80,-80}}, color={28,108,200}),
            Text(
              extent={{-64,66},{-20,46}},
              lineColor={28,108,200},
              textString="DC"),
            Text(
              extent={{28,-52},{72,-72}},
              lineColor={28,108,200},
              textString="DC")}));
    end DCDCconverter;

    model transfo_controlled
      extends Modelica.Electrical.Analog.Interfaces.TwoPort;

      Modelica.Blocks.Interfaces.RealInput alpha annotation (Placement(transformation(
            extent={{-20,-20},{20,20}},
            rotation=270,
            origin={-2,78}), iconTransformation(
            extent={{-14,-14},{14,14}},
            rotation=270,
            origin={0,86})));
    equation
        v2 = alpha* v1;
        i1 = -alpha* i2;

      annotation (Icon(graphics={
            Rectangle(
              extent={{-80,70},{80,-70}},
              lineColor={0,0,0},
              fillColor={215,215,215},
              fillPattern=FillPattern.Solid),
            Line(
              points={{80,70},{-80,-70}},
              color={0,0,0},
              smooth=Smooth.None),
            Line(
              points={{-62,54},{-36,54}},
              color={0,0,0},
              smooth=Smooth.None),
            Line(
              points={{-62,48},{-36,48}},
              color={0,0,0},
              smooth=Smooth.None),
            Line(
              points={{42,-48},{68,-48}},
              color={0,0,0},
              smooth=Smooth.None),
            Line(
              points={{42,-54},{68,-54}},
              color={0,0,0},
              smooth=Smooth.None),
            Text(
              extent={{-38,26},{48,-30}},
              lineColor={0,0,0},
              fillColor={215,215,215},
              fillPattern=FillPattern.Solid,
              textString="TF")}), Diagram(graphics={
            Ellipse(extent={{-45,-50},{-20,-25}}, lineColor={0,0,255}),
            Ellipse(extent={{-45,-25},{-20,0}}, lineColor={0,0,255}),
            Ellipse(extent={{-45,0},{-20,25}}, lineColor={0,0,255}),
            Ellipse(extent={{-45,25},{-20,50}}, lineColor={0,0,255}),
            Rectangle(
              extent={{-72,-60},{-33,60}},
              lineColor={255,255,255},
              fillColor={255,255,255},
              fillPattern=FillPattern.Solid),
            Line(points={{-96,50},{-32,50}}, color={0,0,255}),
            Line(points={{-96,-50},{-32,-50}}, color={0,0,255}),
            Ellipse(extent={{20,-50},{45,-25}}, lineColor={0,0,255}),
            Ellipse(extent={{20,-25},{45,0}}, lineColor={0,0,255}),
            Ellipse(extent={{20,0},{45,25}}, lineColor={0,0,255}),
            Ellipse(extent={{20,25},{45,50}}, lineColor={0,0,255}),
            Rectangle(
              extent={{33,-60},{72,60}},
              lineColor={255,255,255},
              fillColor={255,255,255},
              fillPattern=FillPattern.Solid),
            Line(points={{32,50},{96,50}}, color={0,0,255}),
            Line(points={{32,-50},{96,-50}}, color={0,0,255})}));
    end transfo_controlled;

    model DCDC_converter_2Q_losses
      extends Modelica.Electrical.Analog.Interfaces.TwoPort;

      Modelica.SIunits.Current I_K1 "Current K1 switch";
      Modelica.SIunits.Current I_K2 "Current K1 switch";

      parameter Modelica.SIunits.Frequency f = 10e3 "Switching frequency";

      // Transistor
      parameter Modelica.SIunits.Voltage V0_T = 0 "Transitor Voltage drop";
      parameter Modelica.SIunits.Resistance R0_T = 150e-3 "Transistor Dynamic resistance";
      parameter Modelica.SIunits.Energy EonEoff_T = (265+135)*1e-6 "Transistor Commutation losses";

      // Diode
      parameter Modelica.SIunits.Voltage V0_D = 3 "Diode Voltage drop";
      parameter Modelica.SIunits.Resistance R0_D = 42e-3 "Diode Dynamic resistance";
      parameter Modelica.SIunits.Energy EonEoff_D = 1/4*192e-9*800 "Diode Commutation losses";

      // Switching ref conditions
      parameter Modelica.SIunits.Voltage Vds_sw = 800 "Commutation reference voltage";
      parameter Modelica.SIunits.Current Id_sw = 20 "Commutation reference current";

      Modelica.Blocks.Interfaces.RealInput alpha annotation (Placement(transformation(
            extent={{-20,-20},{20,20}},
            rotation=270,
            origin={-2,78}), iconTransformation(
            extent={{-14,-14},{14,14}},
            rotation=270,
            origin={0,86})));
      Modelica.Thermal.HeatTransfer.Interfaces.HeatPort_a lossK1
        annotation (Placement(transformation(extent={{-60,-112},{-40,-92}})));
      Modelica.Thermal.HeatTransfer.Interfaces.HeatPort_a lossK2
        annotation (Placement(transformation(extent={{40,-112},{60,-92}})));
    equation

      // Hacheur = Transformateur DC-DC de rapport de transformation alpha

        v2 = alpha* v1;
      //  i1 = -alpha* i2;

      // Courants dans les interrupteurs K1 (haut) et K2 (bas)

      I_K1=if (i2<0) then -i2 else 0;  // si i2 < 0 courant sortant vers charge
      I_K2=if (i2>0) then i2 else 0;

      // Calcul des pertes
      // convention positive si flux de chaleur entrant, ici pertes sortent

      lossK1.Q_flow = -((V0_T*sqrt(alpha)*I_K1+R0_T*(sqrt(alpha)*I_K1)^2+f*EonEoff_T*v1/Vds_sw*I_K1/Id_sw)+
                          (V0_D*sqrt(alpha)*I_K2+R0_D*(sqrt(alpha)*I_K2)^2+f*EonEoff_D*v1/Vds_sw*I_K2/Id_sw));

      lossK2.Q_flow = -((V0_T*sqrt(1-alpha)*I_K2+R0_T*(sqrt(1-alpha)*I_K2)^2+f*EonEoff_T*v1/Vds_sw*I_K2/Id_sw)+
                          (V0_D*sqrt(1-alpha)*I_K1+R0_D*(sqrt(1-alpha)*I_K1)^2+f*EonEoff_D*v1/Vds_sw*I_K1/Id_sw));

      // Calcul du courant i1 via la puissance totale
      v1*i1 + v2*i2 = lossK1.Q_flow +   lossK2.Q_flow;

      annotation (Icon(graphics={
            Rectangle(
              extent={{-80,70},{80,-70}},
              lineColor={0,0,0},
              fillColor={215,215,215},
              fillPattern=FillPattern.Solid),
            Line(
              points={{80,70},{-80,-70}},
              color={0,0,0},
              smooth=Smooth.None),
            Line(
              points={{-62,54},{-36,54}},
              color={0,0,0},
              smooth=Smooth.None),
            Line(
              points={{-62,48},{-36,48}},
              color={0,0,0},
              smooth=Smooth.None),
            Line(
              points={{42,-48},{68,-48}},
              color={0,0,0},
              smooth=Smooth.None),
            Line(
              points={{42,-54},{68,-54}},
              color={0,0,0},
              smooth=Smooth.None),
            Text(
              extent={{-36,-76},{0,-102}},
              lineColor={0,0,0},
              fillColor={215,215,215},
              fillPattern=FillPattern.Solid,
              textString="K1"),
            Text(
              extent={{62,-76},{98,-102}},
              lineColor={0,0,0},
              fillColor={215,215,215},
              fillPattern=FillPattern.Solid,
              textString="K2")}), Diagram(graphics={
            Ellipse(extent={{-45,-50},{-20,-25}}, lineColor={0,0,255}),
            Ellipse(extent={{-45,-25},{-20,0}}, lineColor={0,0,255}),
            Ellipse(extent={{-45,0},{-20,25}}, lineColor={0,0,255}),
            Ellipse(extent={{-45,25},{-20,50}}, lineColor={0,0,255}),
            Rectangle(
              extent={{-72,-60},{-33,60}},
              lineColor={255,255,255},
              fillColor={255,255,255},
              fillPattern=FillPattern.Solid),
            Line(points={{-96,50},{-32,50}}, color={0,0,255}),
            Line(points={{-96,-50},{-32,-50}}, color={0,0,255}),
            Ellipse(extent={{20,-50},{45,-25}}, lineColor={0,0,255}),
            Ellipse(extent={{20,-25},{45,0}}, lineColor={0,0,255}),
            Ellipse(extent={{20,0},{45,25}}, lineColor={0,0,255}),
            Ellipse(extent={{20,25},{45,50}}, lineColor={0,0,255}),
            Rectangle(
              extent={{33,-60},{72,60}},
              lineColor={255,255,255},
              fillColor={255,255,255},
              fillPattern=FillPattern.Solid),
            Line(points={{32,50},{96,50}}, color={0,0,255}),
            Line(points={{32,-50},{96,-50}}, color={0,0,255})}));
    end DCDC_converter_2Q_losses;

    model PowerConverterGlobalParameters "Power Converter Global Parameters"

      parameter Modelica.SIunits.Voltage E=300 "DC bus voltage";
      parameter Modelica.SIunits.Inductance L=20e-6 "Filter inductance";
      parameter Modelica.SIunits.Time T=1/10e3 "Switching period";

      annotation (Icon(coordinateSystem(preserveAspectRatio=false), graphics={
            Rectangle(
              extent={{-100,100},{100,-100}},
              lineColor={0,0,0},
              fillColor={215,215,215},
              fillPattern=FillPattern.Solid),
            Line(points={{0,34},{0,76}}, color={0,0,0}),
            Line(points={{0,-70},{0,-30},{34,30}}, color={0,0,0}),
            Rectangle(
              extent={{-4,84},{4,76}},
              lineColor={0,0,0},
              fillColor={215,215,215},
              fillPattern=FillPattern.None),
            Rectangle(
              extent={{-4,-70},{4,-78}},
              lineColor={0,0,0},
              fillColor={215,215,215},
              fillPattern=FillPattern.None),
            Text(
              extent={{-74,-66},{84,-110}},
              lineColor={28,108,200},
              fillColor={215,215,215},
              fillPattern=FillPattern.None,
              textString="Parameters")}),                            Diagram(
            coordinateSystem(preserveAspectRatio=false)));
    end PowerConverterGlobalParameters;

    model Inductor "R-L inductor with RMS losses due current riple"

      parameter Modelica.SIunits.Resistance R=1 "Resistance at temperature T_ref";
      parameter Modelica.SIunits.Inductance L=1e-3 "Inductance";

      parameter Modelica.SIunits.Voltage E=300 "DC bus voltage";
      parameter Modelica.SIunits.Time T=1/10e3 "Switching period";

      Modelica.SIunits.Current DeltaI "Current ripple";
      Modelica.SIunits.Current I_RMS "RMS Current";
      Modelica.SIunits.Current I_L "Current";

      Modelica.Electrical.Analog.Basic.Inductor inductor(L=L)
        annotation (Placement(transformation(extent={{40,-10},{60,10}})));
      Modelica.Electrical.Analog.Basic.Resistor resistor(R=R)
        annotation (Placement(transformation(extent={{-50,-10},{-30,10}})));
      Modelica.Electrical.Analog.Interfaces.PositivePin p1
        "Positive pin (potential p.v > n.v for positive voltage drop v)"
        annotation (Placement(transformation(extent={{-110,-10},{-90,10}})));
      Modelica.Electrical.Analog.Interfaces.NegativePin n1
                    "Negative pin"
        annotation (Placement(transformation(extent={{90,-10},{110,10}})));

      Modelica.Thermal.HeatTransfer.Interfaces.HeatPort_a port_a annotation (
          Placement(transformation(extent={{-10,-70},{10,-50}}), iconTransformation(
              extent={{-10,-70},{10,-50}})));
      Modelica.Blocks.Interfaces.RealInput alpha annotation (Placement(transformation(
            extent={{-20,-20},{20,20}},
            rotation=270,
            origin={0,68}),  iconTransformation(
            extent={{-14,-14},{14,14}},
            rotation=270,
            origin={0,62})));
    equation

      I_L=p1.i;

      DeltaI=E*(1-alpha)*alpha*T/L;

      I_RMS=sqrt(I_L^2+1/12*DeltaI^2);

      port_a.Q_flow = -R*I_RMS^2;

      connect(resistor.p, p1)
        annotation (Line(points={{-50,0},{-100,0}}, color={0,0,255}));
      connect(resistor.n, inductor.p)
        annotation (Line(points={{-30,0},{40,0}}, color={0,0,255}));
      connect(inductor.n, n1)
        annotation (Line(points={{60,0},{100,0}}, color={0,0,255}));
      annotation (Icon(coordinateSystem(preserveAspectRatio=false), graphics={
            Rectangle(
              extent={{-80,40},{80,-40}},
              fillColor={215,215,215},
              fillPattern=FillPattern.Solid,
              lineColor={0,0,0}),
            Line(points={{-100,0},{-70,0},{-60,20},{-50,-20},{-40,20},{-30,0},{-10,0}},
                color={0,0,0}),
            Ellipse(
              extent={{-10,-20},{10,20}},
              lineColor={0,0,0},
              fillColor={215,215,215},
              fillPattern=FillPattern.None),
            Ellipse(
              extent={{10,-20},{30,20}},
              lineColor={0,0,0},
              fillColor={215,215,215},
              fillPattern=FillPattern.None),
            Ellipse(
              extent={{30,-20},{50,20}},
              lineColor={0,0,0},
              fillColor={215,215,215},
              fillPattern=FillPattern.None),
            Ellipse(
              extent={{50,-20},{70,20}},
              lineColor={0,0,0},
              fillColor={215,215,215},
              fillPattern=FillPattern.None),
            Rectangle(
              extent={{76,-20},{-12,-2}},
              pattern=LinePattern.None,
              lineColor={0,0,0},
              fillColor={215,215,215},
              fillPattern=FillPattern.Solid),
            Line(points={{70,0},{100,0}}, color={0,0,0}),
            Text(
              extent={{-74,76},{-12,48}},
              lineColor={0,0,0},
              fillColor={215,215,215},
              fillPattern=FillPattern.Solid,
              textString="Alpha")}),                        Diagram(
            coordinateSystem(preserveAspectRatio=false)));
    end Inductor;

    model Capacitor

      parameter Modelica.SIunits.Resistance Rs=1e-3 "Serial resistance";
      parameter Modelica.SIunits.Capacitance C=100e-3 "Capacitance";

      parameter Modelica.SIunits.Inductance L=1e-3 "Inductance";
      parameter Modelica.SIunits.Voltage E=300 "DC bus voltage";
      parameter Modelica.SIunits.Time T=1/10e3 "Switching period";

      Modelica.SIunits.Current DeltaI "Current ripple (inductor)";
      Modelica.SIunits.Current I_L "Current in inductor";

      Modelica.SIunits.Current I_RMS "RMS Current (Capacitor)";
      Modelica.SIunits.Current DeltaV "Voltage ripple";

      Modelica.Blocks.Interfaces.RealInput alpha annotation (Placement(transformation(
            extent={{-20,-20},{20,20}},
            rotation=0,
            origin={-86,0}), iconTransformation(
            extent={{-14,-14},{14,14}},
            rotation=0,
            origin={-74,0})));
      Modelica.Thermal.HeatTransfer.Interfaces.HeatPort_a port_a annotation (
          Placement(transformation(extent={{60,-10},{80,10}}),   iconTransformation(
              extent={{60,-10},{80,10}})));
      Modelica.Electrical.Analog.Basic.Capacitor capacitor(v(fixed=true, start=
              InitialVoltage), C=C)                        annotation (Placement(
            transformation(
            extent={{-10,-10},{10,10}},
            rotation=270,
            origin={0,0})));
      Modelica.Electrical.Analog.Interfaces.PositivePin p1
        "Positive pin (potential p.v > n.v for positive voltage drop v)"
        annotation (Placement(transformation(extent={{-110,90},{-90,110}}),
            iconTransformation(extent={{-110,90},{-90,110}})));
      Modelica.Electrical.Analog.Interfaces.NegativePin n1
                    "Negative pin"
        annotation (Placement(transformation(extent={{-10,-110},{10,-90}})));
      Modelica.Electrical.Analog.Interfaces.PositivePin p2
        "Positive pin (potential p.v > n.v for positive voltage drop v)"
        annotation (Placement(transformation(extent={{90,90},{110,110}}),
            iconTransformation(extent={{90,90},{110,110}})));
      Modelica.Electrical.Analog.Sensors.CurrentSensor Isensor
        annotation (Placement(transformation(extent={{20,80},{40,100}})));
      parameter Modelica.SIunits.Voltage InitialVoltage=300 "Initial voltage";
    equation

      I_L=if (alpha<=0.00001) then 0 else Isensor.i/alpha;

      DeltaI=E*(1-alpha)*alpha*T/L;
      I_RMS=sqrt(alpha*(1-alpha))*sqrt(I_L^2+1/12*DeltaI^2);

      DeltaV=I_L*(1-alpha)*alpha*T/C;

      port_a.Q_flow = -Rs*I_RMS^2;

      connect(capacitor.n, n1)
        annotation (Line(points={{-1.77636e-15,-10},{-1.77636e-15,-64},{0,-64},{0,-100}},
                                                    color={0,0,255}));

      connect(Isensor.n, p2)
        annotation (Line(points={{40,90},{70,90},{70,100},{100,100}},
                                                   color={0,0,255}));
      connect(Isensor.p, p1)
        annotation (Line(points={{20,90},{-40,90},{-40,100},{-100,100}},
                                                    color={0,0,255}));
      connect(Isensor.p, capacitor.p) annotation (Line(points={{20,90},{1.77636e-15,
              90},{1.77636e-15,10}}, color={0,0,255}));
      annotation (Icon(coordinateSystem(preserveAspectRatio=false), graphics={
            Rectangle(
              extent={{-50,80},{54,-80}},
              fillColor={215,215,215},
              fillPattern=FillPattern.Solid,
              lineColor={0,0,0}),
            Line(points={{0,100},{0,70},{20,60},{-20,50},{20,40},{0,30},{0,-10},
                  {-40,-10},{40,-10}},
                                  color={0,0,0}),
            Line(points={{-18,-12}}, color={0,0,0}),
            Line(points={{40,-20},{-40,-20},{0,-20},{0,-100}}, color={0,0,0}),
            Line(points={{-90,100},{90,100}},
                                            color={0,0,0})}),
          Diagram(coordinateSystem(preserveAspectRatio=false)));
    end Capacitor;

    model HeatSink
      Modelica.Thermal.HeatTransfer.Components.HeatCapacitor heatCapacitor(C=C)
        annotation (Placement(transformation(extent={{30,10},{50,30}})));
      Modelica.Thermal.HeatTransfer.Interfaces.HeatPort_a port_a
        annotation (Placement(transformation(extent={{90,-10},{110,10}})));
      Modelica.Thermal.HeatTransfer.Components.ThermalResistor thermalResistor(
          R=R) annotation (Placement(transformation(
            extent={{-10,-10},{10,10}},
            rotation=180,
            origin={-10,0})));
      Modelica.Thermal.HeatTransfer.Interfaces.HeatPort_b port_b
        annotation (Placement(transformation(extent={{-110,-10},{-90,10}})));
      parameter Modelica.SIunits.HeatCapacity C=1
        "Heat capacity of element (= cp*m)";
      parameter Modelica.SIunits.ThermalResistance R=1
        "Constant thermal resistance of material";
    equation
      connect(heatCapacitor.port, port_a)
        annotation (Line(points={{40,10},{40,0},{100,0}}, color={191,0,0}));
      connect(thermalResistor.port_a, port_a)
        annotation (Line(points={{0,0},{100,0}}, color={191,0,0}));
      connect(thermalResistor.port_b, port_b)
        annotation (Line(points={{-20,0},{-100,0}}, color={191,0,0}));
      annotation (Icon(coordinateSystem(preserveAspectRatio=false), graphics={
              Polygon(
              points={{100,-90},{-100,-90},{-100,-70},{60,-70},{60,-50},{-100,
                  -50},{-100,-30},{60,-30},{60,-10},{-100,-10},{-100,10},{60,10},
                  {60,30},{-100,30},{-100,50},{60,50},{60,70},{-100,70},{-100,
                  90},{60,90},{100,90},{100,-90}},
              lineColor={0,0,0},
              fillColor={215,215,215},
              fillPattern=FillPattern.Solid)}), Diagram(coordinateSystem(
              preserveAspectRatio=false)));
    end HeatSink;
  end Electrical_Components;

  package Storage_Components
    model Cell
      Modelica.Electrical.Analog.Basic.Capacitor C2(C=3.19e4) annotation (
        Placement(visible = true, transformation(origin={26,22},    extent = {{-10, -10}, {10, 10}}, rotation = 0)));
      Modelica.Electrical.Analog.Interfaces.NegativePin pin_n annotation (
        Placement(visible = true, transformation(origin={100,-40},    extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {0, -96}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
      Modelica.Electrical.Analog.Basic.Resistor R1(R=1e-3,     useHeatPort = true) annotation (
        Placement(visible = true, transformation(origin={-10,40},    extent = {{-10, -10}, {10, 10}}, rotation = 0)));
      Modelica.Electrical.Analog.Basic.Resistor R2(R=1.88e-3, useHeatPort=true)
                                                              annotation (
        Placement(visible = true, transformation(origin={26,58},    extent = {{-10, -10}, {10, 10}}, rotation = 0)));
      Modelica.Electrical.Analog.Sensors.CurrentSensor currentSensor annotation (
        Placement(visible = true, transformation(origin={64,40},     extent={{10,-10},
                {-10,10}},                                                                            rotation = 180)));
      Modelica.Electrical.Analog.Interfaces.PositivePin pin_p annotation (
        Placement(visible = true, transformation(origin={100,40},    extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-2, 98}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
      Modelica.Electrical.Analog.Sources.SignalVoltage signalVoltage annotation (
        Placement(visible = true, transformation(origin={-40,0},     extent = {{-10, 10}, {10, -10}}, rotation = -90)));
      Modelica.Blocks.Math.Gain inv_capa(k=1/(50*3600))                  annotation (
        Placement(visible = true, transformation(origin={10,80},     extent = {{-10, -10}, {10, 10}}, rotation = 180)));
      Modelica.Blocks.Continuous.LimIntegrator
                                            limIntegrator(
        outMax=1,
        outMin=0,                                      initType = Modelica.Blocks.Types.Init.InitialOutput, k = 1, y_start = SOC) annotation (
        Placement(visible = true, transformation(origin={-24,80},    extent = {{10, -10}, {-10, 10}}, rotation = 0)));
      Modelica.Thermal.HeatTransfer.Components.HeatCapacitor heatCapacitor(C=356, T(
            fixed=true, start=Tinit))                                               annotation (
        Placement(visible = true, transformation(origin={10,0},      extent = {{-10, -10}, {10, 10}}, rotation = 0)));
      Modelica.Thermal.HeatTransfer.Components.ThermalResistor thermalResistor(R=11)    annotation (
        Placement(visible = true, transformation(origin={36,-24},    extent = {{-10, -10}, {10, 10}}, rotation = 90)));

      parameter Real SOC = 1 "Initial State of Charge (0 = empty, 1 = full)";
      Modelica.Blocks.Tables.CombiTable1D SOC_to_Voc(table=[0,2.5; 0.0806142,3.2; 0.15930902,
            3.21; 0.26295585,3.25; 0.3646833,3.28; 0.46833013,3.3; 0.55662188,3.3; 0.64491363,
            3.3; 0.81765835,3.35; 0.88099808,3.35; 0.94241843,3.35; 1,3.45],
        smoothness=Modelica.Blocks.Types.Smoothness.ContinuousDerivative,
        extrapolation=Modelica.Blocks.Types.Extrapolation.HoldLastPoint,
        verboseExtrapolation=true)                                                                                                                                                                                                         annotation (
        Placement(visible = true, transformation(origin={-74,0},     extent = {{-10, -10}, {10, 10}}, rotation = 0)));
      Modelica.Thermal.HeatTransfer.Interfaces.HeatPort_a port_heat annotation (
          Placement(transformation(extent={{-110,-70},{-90,-50}}),
            iconTransformation(extent={{-110,-70},{-90,-50}})));
      parameter Modelica.SIunits.Temperature Tinit=278 + 20
        "Initial Temperature";
    equation
      connect(R2.p, C2.p) annotation (
        Line(points={{16,58},{16,22}},      color = {0, 0, 255}));
      connect(R2.n, C2.n) annotation (
        Line(points={{36,58},{36,22}},      color = {0, 0, 255}));
      connect(signalVoltage.n, pin_n) annotation (
        Line(points={{-40,-10},{-40,-40},{100,-40}},         color = {0, 0, 255}));
      connect(inv_capa.y, limIntegrator.u)
        annotation (Line(points={{-1,80},{-12,80}}, color={0,0,127}));
      connect(R1.heatPort, heatCapacitor.port) annotation (
        Line(points={{-10,30},{-10,-20},{10,-20},{10,-10}},                     color = {191, 0, 0}));
      connect(SOC_to_Voc.y[1], signalVoltage.v) annotation (
        Line(points={{-63,0},{-58,0},{-58,2.22045e-15},{-52,2.22045e-15}},
                                              color = {0, 0, 127}));
      connect(R1.p, signalVoltage.p) annotation (
        Line(points={{-20,40},{-40,40},{-40,10}},                      color = {0, 0, 255}));
      connect(R1.n, C2.p)
        annotation (Line(points={{0,40},{16,40},{16,22}}, color={0,0,255}));
      connect(R2.heatPort, R1.heatPort)
        annotation (Line(points={{26,48},{26,30},{-10,30}}, color={191,0,0}));
      connect(heatCapacitor.port, thermalResistor.port_b)
        annotation (Line(points={{10,-10},{36,-10},{36,-14}}, color={191,0,0}));
      connect(thermalResistor.port_a, port_heat) annotation (Line(points={{36,-34},{
              38,-34},{38,-60},{-100,-60}}, color={191,0,0}));
      connect(pin_n, pin_n)
        annotation (Line(points={{100,-40},{100,-40}}, color={0,0,255}));
      connect(currentSensor.i, inv_capa.u)
        annotation (Line(points={{64,51},{64,80},{22,80}}, color={0,0,127}));
      connect(currentSensor.p, C2.n)
        annotation (Line(points={{54,40},{36,40},{36,22}}, color={0,0,255}));
      connect(currentSensor.n, pin_p)
        annotation (Line(points={{74,40},{100,40}}, color={0,0,255}));
      connect(limIntegrator.y, SOC_to_Voc.u[1]) annotation (Line(points={{-35,
              80},{-92,80},{-92,0},{-86,0}}, color={0,0,127}));
      annotation (
        Icon(graphics={  Ellipse(origin = {-2, 53}, extent = {{-38, 9}, {38, -9}}, endAngle = 360), Ellipse(origin = {-2, -47}, extent = {{-38, 9}, {38, -9}}, endAngle = 360), Line(origin = {-40, 2.9576}, points = {{0, 49.7269}, {0, -50.2731}, {0, -50.2731}}), Line(origin = {35.922, 2.6345}, points = {{0, 49.7269}, {0, -50.2731}, {0, -50.2731}}), Text(origin = {17, -65}, extent = {{-35, 7}, {35, -7}}, textString = "Cell"), Ellipse(origin = {-9, 54},
                lineThickness =                                                                                                                                                                                                        0.5, extent = {{-7, 2}, {21, -4}}, endAngle = 360), Line(origin = {-0.66, 4.64}, points = {{-1.12557, 31.0285}, {18.8744, 23.0285}, {-7.12557, -4.97151}, {12.8744, -6.9715}, {-25.1256, -38.9715}, {-5.12557, -12.9715}, {-21.1256, -10.9715}, {-1.12557, 31.0285}, {-1.12557, 31.0285}}, thickness = 1), Line(origin = {-2, 71.25}, points = {{0, -18}, {0, 18}}, color = {0, 0, 255}), Line(origin = {0, -73}, points = {{0, 17}, {0, -17}}, color = {0, 0, 255}), Line(origin={
                  -59.55,-61.67},                                                                                                                                                                                                        points = {{25.5538, -0.330714}, {13.5538, -0.330714}, {9.5538, 9.66929}, {5.55381, -6.33071}, {-0.446191, 9.66929}, {-4.44619, -6.33071}, {-10.4462, 9.66929}, {-14.4462, -6.33071}, {-18.4462, 1.66929}, {-26.4462, 1.66929}}, color = {255, 0, 0}, pattern = LinePattern.Dot)}, coordinateSystem(initialScale = 0.1)));
    end Cell;

    model ModulePack
      Modelica.Electrical.Analog.Sensors.VoltageSensor voltageSensor annotation (
        Placement(visible = true, transformation(origin = {2, 8}, extent = {{10, -10}, {-10, 10}}, rotation = 90)));
      Modelica.Electrical.Analog.Sensors.CurrentSensor currentSensor annotation (
        Placement(visible = true, transformation(origin = {126, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
      Modelica.Electrical.Analog.Sources.SignalVoltage fem annotation (
        Placement(visible = true, transformation(origin = {100, 4}, extent = {{10, -10}, {-10, 10}}, rotation = 90)));
      Modelica.Electrical.Analog.Interfaces.PositivePin pin_p annotation (
        Placement(visible = true, transformation(origin = {166, 40}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-20, 100}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
      Modelica.Electrical.Analog.Interfaces.NegativePin pin_n annotation (
        Placement(visible = true, transformation(origin = {166, -24}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {50, 102}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
      Modelica.Electrical.Analog.Sources.SignalCurrent signalCurrent annotation (
        Placement(visible = true, transformation(origin = {40, 6}, extent = {{-10, -10}, {10, 10}}, rotation = -90)));
      Modelica.Blocks.Math.Gain nb_parallele(k = 1 / nombre_parallele) annotation (
        Placement(visible = true, transformation(origin = {82, 60}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
      Modelica.Blocks.Math.Gain nb_serie(k = nombre_serie) annotation (
        Placement(visible = true, transformation(origin = {60, -58}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
      Modelica.Thermal.HeatTransfer.Sources.PrescribedHeatFlow prescribedHeatFlow annotation (
        Placement(visible = true, transformation(origin = {-140, -10}, extent = {{-10, -10}, {10, 10}}, rotation = 90)));
      Modelica.Blocks.Math.Gain NpxNs(k=-nombre_parallele*nombre_serie)    annotation (
        Placement(visible = true, transformation(origin = {-116, -32}, extent = {{-10, -10}, {10, 10}}, rotation = 180)));
      Modelica.Thermal.HeatTransfer.Interfaces.HeatPort_a port_a annotation (
        Placement(visible = true, transformation(origin = {-172, 18}, extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-100, 0}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
      Modelica.Electrical.Analog.Basic.Ground ground annotation (
        Placement(visible = true, transformation(origin = {2, -42}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
      Modelica.Thermal.HeatTransfer.Sources.PrescribedTemperature prescribedTemperature annotation (
        Placement(visible = true, transformation(origin = {-100, 44}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
      Modelica.Thermal.HeatTransfer.Sensors.HeatFlowSensor heatFlowSensor annotation (
        Placement(visible = true, transformation(origin = {-76, 12}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
      Modelica.Thermal.HeatTransfer.Sensors.TemperatureSensor temperatureSensor annotation (
        Placement(visible = true, transformation(origin = {-130, 44}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
      parameter Real nombre_parallele = 1;
      parameter Real nombre_serie = 7;
    Cell Cellule(SOC=SOC, Tinit(displayUnit="K") = Tinit) annotation (Placement(
            visible=true, transformation(
            origin={-34,10},
            extent={{-18,-18},{18,18}},
            rotation=0)));
      parameter Real SOC=1 "Initial State of Charge (0 = empty, 1 = full)";
      parameter Modelica.SIunits.Temperature Tinit=278 + 20
        "Initial Temperature";
    equation
      connect(fem.n, pin_n) annotation (
        Line(points = {{100, -6}, {100, -6}, {100, -24}, {166, -24}, {166, -24}}, color = {0, 0, 255}));
      connect(currentSensor.i, nb_parallele.u) annotation (
        Line(points = {{126, 51}, {126, 60}, {94, 60}}, color = {0, 0, 127}));
      connect(nb_parallele.y, signalCurrent.i) annotation (
        Line(points = {{71, 60}, {60, 60}, {60, 6}, {52, 6}}, color = {0, 0, 127}));
      connect(nb_serie.y, fem.v) annotation (
        Line(points = {{71, -58}, {84, -58}, {84, 4}, {88, 4}}, color = {0, 0, 127}));
      connect(NpxNs.y, prescribedHeatFlow.Q_flow) annotation (
        Line(points = {{-127, -32}, {-140, -32}, {-140, -20}}, color = {0, 0, 127}));
      connect(prescribedHeatFlow.port, port_a) annotation (
        Line(points = {{-140, 0}, {-140, 18}, {-172, 18}}, color = {191, 0, 0}));
      connect(prescribedTemperature.port, heatFlowSensor.port_a) annotation (
        Line(points = {{-90, 44}, {-90, 12}, {-86, 12}}, color = {191, 0, 0}));
      connect(heatFlowSensor.Q_flow, NpxNs.u) annotation (
        Line(points = {{-76, 2}, {-76, -32}, {-104, -32}}, color = {0, 0, 127}));
      connect(temperatureSensor.port, port_a) annotation (
        Line(points = {{-140, 44}, {-140, 18}, {-172, 18}}, color = {191, 0, 0}));
      connect(temperatureSensor.T, prescribedTemperature.T) annotation (
        Line(points = {{-120, 44}, {-112, 44}}, color = {0, 0, 127}));
    connect(nb_serie.u, voltageSensor.v) annotation (
        Line(points = {{48, -58}, {20, -58}, {20, 8}, {13, 8}}, color = {0, 0, 127}));
      connect(Cellule.pin_p, signalCurrent.p) annotation (Line(points={{-34.36,
              27.64},{-34.36,27.64},{-34.36,34},{40,34},{40,16},{40,16}}, color=
             {0,0,255}));
      connect(signalCurrent.n, Cellule.pin_n) annotation (Line(points={{40,-4},
              {40,-4},{40,-20},{-34,-20},{-34,-7.28},{-34,-7.28}}, color={0,0,
              255}));
      connect(ground.p, Cellule.pin_n) annotation (Line(points={{2,-32},{2,-32},
              {2,-20},{-34,-20},{-34,-7.28},{-34,-7.28}}, color={0,0,255}));
      connect(voltageSensor.p, Cellule.pin_p) annotation (Line(points={{2,18},{
              2,34},{-34.36,34},{-34.36,27.64}}, color={0,0,255}));
      connect(voltageSensor.n, Cellule.pin_n) annotation (Line(points={{2,-2},{
              2,-20},{-34,-20},{-34,-7.28}}, color={0,0,255}));
    connect(currentSensor.p, pin_p) annotation (
        Line(points = {{136, 40}, {168, 40}, {168, 40}, {166, 40}}, color = {0, 0, 255}));
    connect(currentSensor.n, fem.p) annotation (
        Line(points = {{116, 40}, {100, 40}, {100, 14}, {100, 14}}, color = {0, 0, 255}));
      connect(Cellule.port_heat, heatFlowSensor.port_b) annotation (Line(points=
             {{-52,-0.8},{-60,-0.8},{-60,12},{-66,12}}, color={191,0,0}));
      annotation (
        Icon(graphics={  Rectangle(origin = {16, -7}, extent = {{-60, 43}, {60, -43}}), Rectangle(origin = {-19, 44}, extent = {{-9, 8}, {9, -8}}), Rectangle(origin = {51, 44}, extent = {{-9, 8}, {9, -8}}), Line(origin = {-19.1848, 44.6797}, points = {{0, 4}, {0, -4}, {0, -4}}), Line(origin = {-19.1848, 44.6797}, rotation = 90, points = {{0, 4}, {0, -4}, {0, -4}}), Line(origin = {51.5178, 44.403}, rotation = 90, points = {{0, 4}, {0, -4}, {0, -4}}), Line(origin = {19.8819, -3.45185}, points = {{-1.12557, 31.0285}, {18.8744, 23.0285}, {-7.12557, -4.97151}, {12.8744, -6.9715}, {-25.1256, -38.9715}, {-5.12557, -12.9715}, {-21.1256, -10.9715}, {-1.12557, 31.0285}, {-1.12557, 31.0285}}, thickness = 1), Text(origin={19,
                  -65},                                                                                                                                                                                                        extent = {{-37, 9}, {37, -9}}, textString = "Module"), Line(origin = {-20.209, 72.3134}, points = {{0, 20}, {0, -20}}, color = {0, 0, 255}), Line(origin = {49.791, 72.3134}, points = {{0, 20}, {0, -20}}, color = {0, 0, 255}), Line(origin = {-69.3115, 0.613627}, points = {{25.5538, -0.330714}, {13.5538, -0.330714}, {9.5538, 9.66929}, {5.55381, -6.33071}, {-0.446191, 9.66929}, {-4.44619, -6.33071}, {-10.4462, 9.66929}, {-14.4462, -6.33071}, {-18.4462, 1.66929}, {-26.4462, 1.66929}}, color = {255, 0, 0}, pattern = LinePattern.Dot)}, coordinateSystem(initialScale = 0.1, extent={
                {-160,-100},{160,100}})), Diagram(coordinateSystem(extent={{-160,-100},
                {160,100}})));
    end ModulePack;

    model Cellbis
      Modelica.Electrical.Analog.Interfaces.NegativePin pin_n annotation (
        Placement(visible = true, transformation(origin={100,-40},    extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {0, -96}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
      Modelica.Electrical.Analog.Sensors.CurrentSensor currentSensor annotation (
        Placement(visible = true, transformation(origin={64,40},     extent={{10,-10},
                {-10,10}},                                                                            rotation = 180)));
      Modelica.Electrical.Analog.Interfaces.PositivePin pin_p annotation (
        Placement(visible = true, transformation(origin={100,40},    extent = {{-10, -10}, {10, 10}}, rotation = 0), iconTransformation(origin = {-2, 98}, extent = {{-10, -10}, {10, 10}}, rotation = 0)));
      Modelica.Electrical.Analog.Sources.SignalVoltage signalVoltage annotation (
        Placement(visible = true, transformation(origin={-40,0},     extent = {{-10, 10}, {10, -10}}, rotation = -90)));
      Modelica.Blocks.Continuous.LimIntegrator
                                            limIntegrator(
        outMax=1,
        outMin=0,                                      initType = Modelica.Blocks.Types.Init.InitialOutput,
        k=-1/3600/52.3,                                                                                            y_start = SOC) annotation (
        Placement(visible = true, transformation(origin={-24,80},    extent = {{10, -10}, {-10, 10}}, rotation = 0)));

      parameter Real SOC = 1 "Initial State of Charge (0 = empty, 1 = full)";
      Modelica.Blocks.Tables.CombiTable1D SOC_to_Voc(table=[0,2.5; 0.0806142,3.2; 0.15930902,
            3.21; 0.26295585,3.25; 0.3646833,3.28; 0.46833013,3.3; 0.55662188,3.3; 0.64491363,
            3.3; 0.81765835,3.35; 0.88099808,3.35; 0.94241843,3.35; 1,3.45],
        smoothness=Modelica.Blocks.Types.Smoothness.ContinuousDerivative,
        extrapolation=Modelica.Blocks.Types.Extrapolation.HoldLastPoint,
        verboseExtrapolation=true)                                                                                                                                                                                                         annotation (
        Placement(visible = true, transformation(origin={-72,0},     extent = {{-10, -10}, {10, 10}}, rotation = 0)));
      Modelica.Thermal.HeatTransfer.Interfaces.HeatPort_a port_heat annotation (
          Placement(transformation(extent={{-110,-70},{-90,-50}}),
            iconTransformation(extent={{-110,-70},{-90,-50}})));
      parameter Modelica.SIunits.Temperature Tinit=278 + 20
        "Initial Temperature";
      Modelica.Thermal.HeatTransfer.Components.HeatCapacitor heatCapacitor(C=1)
        annotation (Placement(transformation(extent={{-68,-70},{-48,-50}})));
    equation
      connect(signalVoltage.n, pin_n) annotation (
        Line(points={{-40,-10},{-40,-40},{100,-40}},         color = {0, 0, 255}));
      connect(SOC_to_Voc.y[1], signalVoltage.v) annotation (
        Line(points={{-61,0},{-58,0},{-58,2.22045e-15},{-52,2.22045e-15}},
                                              color = {0, 0, 127}));
      connect(pin_n, pin_n)
        annotation (Line(points={{100,-40},{100,-40}}, color={0,0,255}));
      connect(currentSensor.n, pin_p)
        annotation (Line(points={{74,40},{100,40}}, color={0,0,255}));
      connect(currentSensor.p, signalVoltage.p)
        annotation (Line(points={{54,40},{-40,40},{-40,10}}, color={0,0,255}));
      connect(limIntegrator.u, currentSensor.i)
        annotation (Line(points={{-12,80},{64,80},{64,51}}, color={0,0,127}));
      connect(limIntegrator.y, SOC_to_Voc.u[1]) annotation (Line(points={{-35,
              80},{-100,80},{-100,0},{-84,0}}, color={0,0,127}));
      connect(heatCapacitor.port, port_heat) annotation (Line(points={{-58,-70},
              {-80,-70},{-80,-60},{-100,-60}}, color={191,0,0}));
      annotation (
        Icon(graphics={  Ellipse(origin = {-2, 53}, extent = {{-38, 9}, {38, -9}}, endAngle = 360), Ellipse(origin = {-2, -47}, extent = {{-38, 9}, {38, -9}}, endAngle = 360), Line(origin = {-40, 2.9576}, points = {{0, 49.7269}, {0, -50.2731}, {0, -50.2731}}), Line(origin = {35.922, 2.6345}, points = {{0, 49.7269}, {0, -50.2731}, {0, -50.2731}}), Text(origin = {17, -65}, extent = {{-35, 7}, {35, -7}}, textString = "Cell"), Ellipse(origin = {-9, 54},
                lineThickness =                                                                                                                                                                                                        0.5, extent = {{-7, 2}, {21, -4}}, endAngle = 360), Line(origin = {-0.66, 4.64}, points = {{-1.12557, 31.0285}, {18.8744, 23.0285}, {-7.12557, -4.97151}, {12.8744, -6.9715}, {-25.1256, -38.9715}, {-5.12557, -12.9715}, {-21.1256, -10.9715}, {-1.12557, 31.0285}, {-1.12557, 31.0285}}, thickness = 1), Line(origin = {-2, 71.25}, points = {{0, -18}, {0, 18}}, color = {0, 0, 255}), Line(origin = {0, -73}, points = {{0, 17}, {0, -17}}, color = {0, 0, 255}), Line(origin={
                  -59.55,-61.67},                                                                                                                                                                                                        points = {{25.5538, -0.330714}, {13.5538, -0.330714}, {9.5538, 9.66929}, {5.55381, -6.33071}, {-0.446191, 9.66929}, {-4.44619, -6.33071}, {-10.4462, 9.66929}, {-14.4462, -6.33071}, {-18.4462, 1.66929}, {-26.4462, 1.66929}}, color = {255, 0, 0}, pattern = LinePattern.Dot)}, coordinateSystem(initialScale = 0.1)));
    end Cellbis;
  end Storage_Components;

  model TestProfile_Cycle "Power"
    parameter Modelica.SIunits.Mass vehicleMass = 1410 "Vehicle mass with cargo";
    //[kg]
    parameter Real rhoAir = 1.2 "Air density";
    //[kg/m3]
    parameter Real S = 2.1 "Front surface";
    //[m2]
    parameter Real Cx = 0.4 "Drag coefficient";
    //[unitless]
    parameter Real Crr = 0.01 "Rolling coefficient";
    //[unitless]
    constant Modelica.SIunits.Acceleration g = Modelica.Constants.g_n "Gravity constant";
    output Real Temps;
    Modelica.Blocks.Sources.CombiTimeTable SpeedTable(
      fileName=
          "C:/Users/mbudinge/Documents/GitHub/EVpowertrain/notebook/modelica/Velocity_Cycle.txt",                                               tableName = "tab1", tableOnFile = true) annotation (
      Placement(visible = true, transformation(origin={-318,12},   extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    Modelica.Blocks.Math.Feedback feedback annotation (
      Placement(visible = true, transformation(origin={-254,12},   extent = {{-10, 10}, {10, -10}}, rotation = 0)));
    Modelica.Mechanics.Translational.Sensors.SpeedSensor speedSensor annotation (
      Placement(visible = true, transformation(origin={-108,64},   extent = {{10, -10}, {-10, 10}}, rotation = 0)));
    Modelica.Blocks.Math.Gain Couple(k=100)    annotation (Placement(visible=
            true, transformation(
          origin={-224,12},
          extent={{-10,-10},{10,10}},
          rotation=0)));
    Modelica.Blocks.Math.Gain Convert1(k=1/3.6)     annotation (
      Placement(visible = true, transformation(origin={-286,12},   extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    Modelica.Mechanics.Translational.Sensors.PositionSensor positionSensor annotation (
      Placement(visible = true, transformation(origin={60,64},    extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    Modelica.Blocks.Tables.CombiTable1D SlopeTable1D(
      fileName=
          "C:/Users/mbudinge/Documents/GitHub/EVpowertrain/notebook/modelica/Slope_Cycle.txt",                               tableName = "tab1", tableOnFile = true) annotation (
      Placement(visible = true, transformation(origin={32,-48},    extent = {{-10, -10}, {10, 10}}, rotation = 90)));
    Modelica.Blocks.Math.Gain Convert2(k = 1 / 1000) annotation (
      Placement(visible = true, transformation(origin={95,-1},     extent={{-11,-11},
              {11,11}},                                                                             rotation = -90)));
    Modelica.Blocks.Math.Gain gain1(k=0.5/100)   annotation (
      Placement(visible = true, transformation(origin={32,-16},     extent = {{-10, -10}, {10, 10}}, rotation = 90)));
    Modelica.Mechanics.Rotational.Components.LossyGear lossyGear1(lossTable=[0,0.88,
          0.88,0,0], ratio=14.87)
      annotation (Placement(transformation(extent={{-92,2},{-72,22}})));
    Modelica.Mechanics.Rotational.Components.Inertia inertiaReducerMotor1(J=0.57e-4)
      annotation (Placement(transformation(extent={{-124,2},{-104,22}})));
    Modelica.Mechanics.Translational.Components.IdealRollingWheel WheelGoupil(radius=
          0.289)
      annotation (Placement(transformation(extent={{-26,2},{-6,22}})));
    Modelica.Mechanics.Rotational.Components.Inertia inertiaWheels(J=1.68)
      annotation (Placement(transformation(extent={{-60,2},{-40,22}})));
    Modelica.Mechanics.Rotational.Sources.Torque torque
      annotation (Placement(transformation(extent={{-176,2},{-156,22}})));
    Mechanical_Components.Goupil goupil
      annotation (Placement(transformation(extent={{14,0},{50,36}})));
    Modelica.Blocks.Math.Product product2 annotation (
      Placement(visible = true, transformation(origin={-196,82},   extent = {{-10, -10}, {10, 10}}, rotation = 90)));
    Modelica.Blocks.Continuous.Integrator Energy_integrator annotation (
      Placement(visible = true, transformation(origin={-146,102},  extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    Modelica.Mechanics.Rotational.Sensors.SpeedSensor speedSensor1 annotation (
        Placement(transformation(
          extent={{-10,-10},{10,10}},
          rotation=90,
          origin={-140,32})));
    Modelica.Blocks.Math.Product product1
                                         annotation (
      Placement(visible = true, transformation(origin={-196,-14},   extent = {{-10, -10}, {10, 10}}, rotation = -90)));
    Modelica.Blocks.Math.Sqrt sqrtFRMS annotation (Placement(transformation(
          extent={{-10,-10},{10,10}},
          rotation=270,
          origin={-196,-74})));
    Modelica.Blocks.Math.ContinuousMean continuousMean annotation (Placement(
          transformation(
          extent={{-10,-10},{10,10}},
          rotation=270,
          origin={-196,-44})));
  equation
    Temps = time + 0.0001 "Simulation time";

    connect(speedSensor.v, feedback.u2) annotation (
      Line(points={{-119,64},{-254,64},{-254,20}},       color = {0, 0, 127}));
    connect(Convert2.y, SlopeTable1D.u[1]) annotation (
      Line(points={{95,-13.1},{95,-61},{32,-61},{32,-60}},                              color = {0, 0, 127}));
    connect(positionSensor.s, Convert2.u) annotation (
      Line(points={{71,64},{96,64},{96,48},{95,48},{95,12.2}},color = {0, 0, 127}));
    connect(SpeedTable.y[1], Convert1.u) annotation (
      Line(points={{-307,12},{-298,12}},    color = {0, 0, 127}));
    connect(Convert1.y, feedback.u1) annotation (
      Line(points={{-275,12},{-262,12}},                          color = {0, 0, 127}));
    connect(feedback.y, Couple.u)
      annotation (Line(points={{-245,12},{-236,12}}, color={0,0,127}));
    connect(SlopeTable1D.y[1], gain1.u)
      annotation (Line(points={{32,-37},{32,-28}}, color={0,0,127}));
    connect(gain1.y, goupil.Slope) annotation (Line(points={{32,-5},{32,4.32}},
                       color={0,0,127}));
    connect(speedSensor.flange, goupil.flange_a) annotation (Line(points={{-98,64},
            {10,64},{10,12.6},{14,12.6}},
                                      color={0,127,0}));
    connect(positionSensor.flange, goupil.flange_a) annotation (Line(points={{50,64},
            {10,64},{10,12.6},{14,12.6}},
                                      color={0,127,0}));
    connect(WheelGoupil.flangeR, inertiaWheels.flange_b)
      annotation (Line(points={{-26,12},{-40,12}},   color={0,0,0}));
    connect(lossyGear1.flange_b, inertiaWheels.flange_a)
      annotation (Line(points={{-72,12},{-60,12}}, color={0,0,0}));
    connect(lossyGear1.flange_a, inertiaReducerMotor1.flange_b)
      annotation (Line(points={{-92,12},{-104,12}}, color={0,0,0}));
    connect(torque.tau, Couple.y)
      annotation (Line(points={{-178,12},{-213,12}}, color={0,0,127}));
    connect(goupil.flange_a, WheelGoupil.flangeT) annotation (Line(points={{14,
            12.6},{20,12.6},{20,12},{-6,12}}, color={0,127,0}));
    connect(speedSensor.v, feedback.u2) annotation (
      Line(points={{-119,64},{-254,64},{-254,20}},       color = {0, 0, 127}));
    connect(product2.y,Energy_integrator. u) annotation (
      Line(points={{-196,93},{-196,102},{-158,102}},                         color = {0, 0, 127}));
    connect(product2.u1, Couple.y) annotation (Line(points={{-202,70},{-202,12},
            {-213,12}}, color={0,0,127}));
    connect(torque.flange, inertiaReducerMotor1.flange_a)
      annotation (Line(points={{-156,12},{-124,12}}, color={0,0,0}));
    connect(speedSensor1.flange, inertiaReducerMotor1.flange_a)
      annotation (Line(points={{-140,22},{-140,12},{-124,12}}, color={0,0,0}));
    connect(speedSensor1.w, product2.u2) annotation (Line(points={{-140,43},{
            -190,43},{-190,70}}, color={0,0,127}));
    connect(continuousMean.u, product1.y)
      annotation (Line(points={{-196,-32},{-196,-25}}, color={0,0,127}));
    connect(continuousMean.y,sqrtFRMS. u)
      annotation (Line(points={{-196,-55},{-196,-62}},
                                                     color={0,0,127}));
    connect(product1.u2, Couple.y) annotation (Line(points={{-202,-2},{-202,12},
            {-213,12}}, color={0,0,127}));
    connect(product1.u1, Couple.y) annotation (Line(points={{-190,-2},{-190,4},
            {-202,4},{-202,12},{-213,12}}, color={0,0,127}));
      annotation (Line(points={{-102,-34},{-90,-34}}),
      experiment(
        StopTime=3080,
        Interval=0.002,
        Tolerance=1e-09,
        __Dymola_Algorithm="Dassl"),
      Diagram(coordinateSystem(extent={{-340,-100},{120,120}},      initialScale = 0.1)),
      Icon(coordinateSystem(extent={{-340,-100},{120,120}}),      graphics={
            Rectangle(extent={{-300,100},{100,-100}}, lineColor={28,108,200}),
            Text(
            extent={{-224,52},{14,-60}},
            lineColor={28,108,200},
            textString="Cycle 1")}),
      __OpenModelica_commandLineOptions = "");
  end TestProfile_Cycle;

  model TestMotor
    Modelica.Blocks.Sources.Step stepSlope1(height=0)    annotation (
      Placement(transformation(extent={{102,8},{122,28}})));
    Modelica.Mechanics.Translational.Components.IdealRollingWheel WheelGoupil1(radius=
          0.289)
      annotation (Placement(transformation(extent={{84,42},{104,62}})));
    Modelica.Mechanics.Rotational.Components.LossyGear ReducerAndDifferential1(lossTable=
         [0,0.88,0.88,0,0], ratio=14.87)
      annotation (Placement(transformation(extent={{46,42},{66,62}})));
    Mechanical_Components.Goupil goupil1
      annotation (Placement(transformation(extent={{114,44},{140,70}})));
    Modelica.Electrical.Analog.Sources.SignalVoltage signalVoltage annotation (
        Placement(transformation(
          extent={{-10,10},{10,-10}},
          rotation=270,
          origin={-110,50})));
    Modelica.Electrical.Analog.Basic.Ground ground
      annotation (Placement(transformation(extent={{-120,8},{-100,28}})));
    Modelica.Electrical.Analog.Basic.Ground ground1
      annotation (Placement(transformation(extent={{-120,-66},{-100,-46}})));
    Modelica.Electrical.Analog.Basic.Resistor resistor(R=21e-3)
      annotation (Placement(transformation(extent={{-70,62},{-50,82}})));
    Modelica.Electrical.Analog.Basic.Inductor inductor(L=18e-6)
      annotation (Placement(transformation(extent={{-42,62},{-22,82}})));
    Modelica.Electrical.Analog.Basic.EMF emf(k=0.12)
      annotation (Placement(transformation(extent={{-20,42},{0,62}})));
    Modelica.Electrical.Analog.Basic.Ground ground2
      annotation (Placement(transformation(extent={{-20,6},{0,26}})));
    Modelica.Blocks.Sources.Step step(
      height=-24,
      offset=24,
      startTime=50)
      annotation (Placement(transformation(extent={{-156,40},{-136,60}})));
    Modelica.Mechanics.Rotational.Components.Inertia inertia(J=0.0238)
      annotation (Placement(transformation(extent={{12,42},{32,62}})));
    Modelica.Blocks.Sources.Step stepSlope2(height=0)    annotation (
      Placement(transformation(extent={{102,-64},{122,-44}})));
    Modelica.Mechanics.Translational.Components.IdealRollingWheel WheelGoupil2(radius=
          0.289)
      annotation (Placement(transformation(extent={{84,-30},{104,-10}})));
    Modelica.Mechanics.Rotational.Components.LossyGear ReducerAndDifferential2(lossTable=
         [0,0.88,0.88,0,0], ratio=14.87)
      annotation (Placement(transformation(extent={{46,-30},{66,-10}})));
    Mechanical_Components.Goupil goupil2
      annotation (Placement(transformation(extent={{114,-28},{140,-2}})));
    Modelica.Electrical.Analog.Basic.Resistor resistor1(R=21e-3)
      annotation (Placement(transformation(extent={{-70,-10},{-50,10}})));
    Modelica.Electrical.Analog.Basic.Inductor inductor1(L=18e-6)
      annotation (Placement(transformation(extent={{-42,-10},{-22,10}})));
    Modelica.Electrical.Analog.Basic.EMF emf1(k=0.12)
      annotation (Placement(transformation(extent={{-20,-30},{0,-10}})));
    Modelica.Electrical.Analog.Basic.Ground ground4
      annotation (Placement(transformation(extent={{-20,-66},{0,-46}})));
    Modelica.Mechanics.Rotational.Components.Inertia inertia1(J=0.0238)
      annotation (Placement(transformation(extent={{12,-30},{32,-10}})));
    Modelica.Electrical.Analog.Sources.SignalVoltage signalVoltage1 annotation (
       Placement(transformation(
          extent={{-10,10},{10,-10}},
          rotation=270,
          origin={-110,-26})));
    Modelica.Electrical.Analog.Sensors.CurrentSensor currentSensor
      annotation (Placement(transformation(extent={{-98,-10},{-78,10}})));
    Modelica.Blocks.Sources.Step step1(
      height=-90,
      offset=90,
      startTime=50)
      annotation (Placement(transformation(extent={{-220,-36},{-200,-16}})));
    Modelica.Blocks.Math.Feedback feedback
      annotation (Placement(transformation(extent={{-196,-36},{-176,-16}})));
    Modelica.Blocks.Math.Gain gain(k=10)
      annotation (Placement(transformation(extent={{-170,-36},{-150,-16}})));
    Modelica.Blocks.Nonlinear.Limiter limiter(uMax=48)
      annotation (Placement(transformation(extent={{-142,-32},{-130,-20}})));
    Modelica.Mechanics.Translational.Sensors.AccSensor accSensor
      annotation (Placement(transformation(extent={{114,70},{134,90}})));
  equation
    connect(goupil1.flange_a, WheelGoupil1.flangeT) annotation (Line(points={{
            114,53.1},{112,53.1},{112,52},{104,52}}, color={0,127,0}));
    connect(stepSlope1.y, goupil1.Slope) annotation (Line(points={{123,18},{127,
            18},{127,47.12}}, color={0,0,127}));
    connect(ReducerAndDifferential1.flange_b, WheelGoupil1.flangeR)
      annotation (Line(points={{66,52},{84,52}}, color={0,0,0}));
    connect(ground.p, signalVoltage.n)
      annotation (Line(points={{-110,28},{-110,40}}, color={0,0,255}));
    connect(ground2.p, emf.n)
      annotation (Line(points={{-10,26},{-10,42}}, color={0,0,255}));
    connect(emf.p, inductor.n)
      annotation (Line(points={{-10,62},{-10,72},{-22,72}}, color={0,0,255}));
    connect(inductor.p, resistor.n)
      annotation (Line(points={{-42,72},{-50,72}}, color={0,0,255}));
    connect(resistor.p, signalVoltage.p) annotation (Line(points={{-70,72},{
            -110,72},{-110,60}}, color={0,0,255}));
    connect(step.y, signalVoltage.v)
      annotation (Line(points={{-135,50},{-122,50}}, color={0,0,127}));
    connect(inertia.flange_a, emf.flange)
      annotation (Line(points={{12,52},{0,52}}, color={0,0,0}));
    connect(inertia.flange_b, ReducerAndDifferential1.flange_a)
      annotation (Line(points={{32,52},{46,52}}, color={0,0,0}));
    connect(goupil2.flange_a, WheelGoupil2.flangeT) annotation (Line(points={{
            114,-18.9},{112,-18.9},{112,-20},{104,-20}}, color={0,127,0}));
    connect(stepSlope2.y, goupil2.Slope) annotation (Line(points={{123,-54},{
            127,-54},{127,-24.88}}, color={0,0,127}));
    connect(ReducerAndDifferential2.flange_b, WheelGoupil2.flangeR)
      annotation (Line(points={{66,-20},{84,-20}}, color={0,0,0}));
    connect(ground4.p, emf1.n)
      annotation (Line(points={{-10,-46},{-10,-30}}, color={0,0,255}));
    connect(emf1.p, inductor1.n)
      annotation (Line(points={{-10,-10},{-10,0},{-22,0}}, color={0,0,255}));
    connect(inductor1.p, resistor1.n)
      annotation (Line(points={{-42,0},{-50,0}}, color={0,0,255}));
    connect(inertia1.flange_a, emf1.flange)
      annotation (Line(points={{12,-20},{0,-20}}, color={0,0,0}));
    connect(inertia1.flange_b, ReducerAndDifferential2.flange_a)
      annotation (Line(points={{32,-20},{46,-20}}, color={0,0,0}));
    connect(ground1.p, signalVoltage1.n)
      annotation (Line(points={{-110,-46},{-110,-36}}, color={0,0,255}));
    connect(currentSensor.n, resistor1.p)
      annotation (Line(points={{-78,0},{-70,0}}, color={0,0,255}));
    connect(currentSensor.p, signalVoltage1.p)
      annotation (Line(points={{-98,0},{-110,0},{-110,-16}}, color={0,0,255}));
    connect(feedback.u1, step1.y)
      annotation (Line(points={{-194,-26},{-199,-26}}, color={0,0,127}));
    connect(signalVoltage1.v, limiter.y)
      annotation (Line(points={{-122,-26},{-129.4,-26}}, color={0,0,127}));
    connect(limiter.u, gain.y)
      annotation (Line(points={{-143.2,-26},{-149,-26}}, color={0,0,127}));
    connect(feedback.y, gain.u)
      annotation (Line(points={{-177,-26},{-172,-26}}, color={0,0,127}));
    connect(feedback.u2, currentSensor.i) annotation (Line(points={{-186,-34},{
            -186,-80},{-88,-80},{-88,-11}}, color={0,0,127}));
    connect(accSensor.flange, goupil1.flange_a)
      annotation (Line(points={{114,80},{114,53.1}}, color={0,127,0}));
    annotation (
      Diagram(coordinateSystem(preserveAspectRatio = true, extent={{-240,-100},
              {150,100}})),
      Icon(coordinateSystem(preserveAspectRatio = true, extent={{-240,-100},{
              150,100}})));
  end TestMotor;

  model Test_Profile
      parameter Modelica.SIunits.Frequency f=10000 "Switching frequency";

    Electrical_Components.transfo_controlled
      chopperStepDown
      annotation (Placement(transformation(extent={{-138,-8},{-118,12}})));
    Modelica.Mechanics.Translational.Components.IdealRollingWheel WheelGoupil1(radius=
          0.289)
      annotation (Placement(transformation(extent={{60,-20},{80,0}})));
    Modelica.Mechanics.Rotational.Components.LossyGear ReducerAndDifferential1(lossTable=
         [0,0.88,0.88,0,0], ratio=14.87)
      annotation (Placement(transformation(extent={{22,-20},{42,0}})));
    Mechanical_Components.Goupil goupil1(v_init=3.8)
      annotation (Placement(transformation(extent={{90,-18},{116,8}})));
    Modelica.Electrical.Analog.Basic.Resistor resistor(R=25e-3, useHeatPort=
          false)
      annotation (Placement(transformation(extent={{-82,0},{-62,20}})));
    Modelica.Electrical.Analog.Basic.EMF emf(k=0.12)
      annotation (Placement(transformation(extent={{-44,-20},{-24,0}})));
    Modelica.Mechanics.Rotational.Components.Inertia inertia(J=0.0238)
      annotation (Placement(transformation(extent={{-12,-20},{8,0}})));
    Modelica.Mechanics.Translational.Sensors.AccSensor accSensor
      annotation (Placement(transformation(extent={{90,8},{110,28}})));
    Modelica.Electrical.Analog.Basic.Ground ground annotation (Placement(
          transformation(extent={{-230,-42},{-210,-22}})));
    Modelica.Electrical.Analog.Basic.Ground ground1
                                                   annotation (Placement(
          transformation(extent={{-44,-52},{-24,-32}})));
    Modelica.Blocks.Nonlinear.Limiter limiter(uMax=1, uMin=0)
      annotation (Placement(transformation(extent={{-6,-6},{6,6}},
          rotation=0,
          origin={-112,64})));
    Modelica.Electrical.Analog.Sensors.CurrentSensor currentSensor
      annotation (Placement(transformation(extent={{-110,20},{-90,0}})));
    Modelica.Blocks.Sources.CombiTimeTable SpeedTable(
      fileName=
          "C:/Users/mbudinge/Documents/GitHub/EVpowertrain/notebook/modelica/Velocity_Cycle.txt",
      tableName="tab1",
      tableOnFile=true)                                                                                                                                                                 annotation (
      Placement(visible = true, transformation(origin={-276,64},   extent = {{-10, -10}, {10, 10}}, rotation = 0)));

    Modelica.Blocks.Math.Gain Convert1(k=1/3.6)     annotation (
      Placement(visible = true, transformation(origin={-246,64},   extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    Modelica.Blocks.Math.Feedback feedbackSpeed annotation (Placement(visible=
            true, transformation(
          origin={-222,64},
          extent={{-10,10},{10,-10}},
          rotation=0)));
    Modelica.Blocks.Math.Gain GainSpeed(k=100) annotation (Placement(visible=
            true, transformation(
          origin={-196,64},
          extent={{-10,-10},{10,10}},
          rotation=0)));
    Modelica.Blocks.Math.Gain Convert2(k=1/1000)     annotation (
      Placement(visible = true, transformation(origin={143,-49},   extent={{-11,-11},
              {11,11}},                                                                             rotation = -90)));
    Modelica.Blocks.Math.Gain gain1(k=0.5/100)   annotation (
      Placement(visible = true, transformation(origin={102,-32},    extent = {{-10, -10}, {10, 10}}, rotation = 90)));
    Modelica.Blocks.Tables.CombiTable1D SlopeTable1D(
      fileName=
          "C:/Users/mbudinge/Documents/GitHub/EVpowertrain/notebook/modelica/Slope_Cycle.txt",
      tableName="tab1",
      tableOnFile=true)                                                                                                                                              annotation (
      Placement(visible = true, transformation(origin={102,-62},   extent = {{-10, -10}, {10, 10}}, rotation = 90)));

    Modelica.Mechanics.Translational.Sensors.PositionSensor positionSensor1
                                                                           annotation (
      Placement(visible = true, transformation(origin={132,38},   extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    Modelica.Mechanics.Translational.Sensors.SpeedSensor speedSensor annotation (
      Placement(visible = true, transformation(origin={60,38},     extent = {{10, -10}, {-10, 10}}, rotation = 0)));
    Modelica.Electrical.Analog.Sources.ConstantVoltage constantVoltage(V=48)
      annotation (Placement(transformation(
          extent={{-10,-10},{10,10}},
          rotation=270,
          origin={-220,-4})));
    Modelica.Blocks.Math.Feedback feedbackCurrent annotation (Placement(visible=
           true, transformation(
          origin={-168,64},
          extent={{-10,10},{10,-10}},
          rotation=0)));
    Modelica.Blocks.Math.Gain GainI(k=100) annotation (Placement(visible=true,
          transformation(
          origin={-140,64},
          extent={{-10,-10},{10,10}},
          rotation=0)));
  equation
    connect(goupil1.flange_a, WheelGoupil1.flangeT) annotation (Line(points={{90,-8.9},
            {88,-8.9},{88,-10},{80,-10}},            color={0,127,0}));
    connect(ReducerAndDifferential1.flange_b, WheelGoupil1.flangeR)
      annotation (Line(points={{42,-10},{60,-10}},
                                                 color={0,0,0}));
    connect(inertia.flange_a, emf.flange)
      annotation (Line(points={{-12,-10},{-24,-10}},
                                                color={0,0,0}));
    connect(inertia.flange_b, ReducerAndDifferential1.flange_a)
      annotation (Line(points={{8,-10},{22,-10}},color={0,0,0}));
    connect(accSensor.flange, goupil1.flange_a)
      annotation (Line(points={{90,18},{90,-8.9}},   color={0,127,0}));
    connect(chopperStepDown.n2, emf.n) annotation (Line(points={{-118,-8},{-120,
            -8},{-120,-20},{-34,-20}},
                                     color={0,0,255}));
    connect(ground1.p, emf.n)
      annotation (Line(points={{-34,-32},{-34,-20}},
                                                   color={0,0,255}));
    connect(currentSensor.p, chopperStepDown.p2)
      annotation (Line(points={{-110,10},{-120,10},{-120,12},{-118,12}},
                                                     color={0,0,255}));
    connect(ground.p, chopperStepDown.n1)
      annotation (Line(points={{-220,-22},{-138,-22},{-138,-8}},
                                                             color={0,0,255}));
    connect(SpeedTable.y[1],Convert1. u) annotation (
      Line(points={{-265,64},{-258,64}},    color = {0, 0, 127}));
    connect(SlopeTable1D.y[1], gain1.u)
      annotation (Line(points={{102,-51},{102,-44}}, color={0,0,127}));
    connect(gain1.y, goupil1.Slope) annotation (Line(points={{102,-21},{102,
            -14.88},{103,-14.88}}, color={0,0,127}));
    connect(Convert2.y, SlopeTable1D.u[1]) annotation (Line(points={{143,-61.1},
            {143,-80},{102,-80},{102,-74}}, color={0,0,127}));
    connect(positionSensor1.flange, accSensor.flange)
      annotation (Line(points={{122,38},{90,38},{90,18}}, color={0,127,0}));
    connect(accSensor.flange, speedSensor.flange)
      annotation (Line(points={{90,18},{90,38},{70,38}}, color={0,127,0}));
    connect(positionSensor1.s, Convert2.u) annotation (Line(points={{143,38},{
            144,38},{144,-35.8},{143,-35.8}}, color={0,0,127}));
    connect(feedbackSpeed.y, GainSpeed.u)
      annotation (Line(points={{-213,64},{-208,64}}, color={0,0,127}));
    connect(Convert1.y, feedbackSpeed.u1)
      annotation (Line(points={{-235,64},{-230,64}}, color={0,0,127}));
    connect(speedSensor.v, feedbackSpeed.u2) annotation (Line(points={{49,38},{
            22,38},{22,86},{-222,86},{-222,72}}, color={0,0,127}));
    connect(resistor.p, currentSensor.n)
      annotation (Line(points={{-82,10},{-90,10}}, color={0,0,255}));
    connect(feedbackCurrent.u1, GainSpeed.y)
      annotation (Line(points={{-176,64},{-185,64}}, color={0,0,127}));
    connect(GainI.u, feedbackCurrent.y)
      annotation (Line(points={{-152,64},{-159,64}}, color={0,0,127}));
    connect(limiter.u, GainI.y) annotation (Line(points={{-119.2,64},{-123.6,64},
            {-123.6,64},{-129,64}}, color={0,0,127}));
    connect(limiter.y, chopperStepDown.alpha) annotation (Line(points={{-105.4,
            64},{-100,64},{-100,34},{-128,34},{-128,10.6}}, color={0,0,127}));
    connect(currentSensor.i, feedbackCurrent.u2) annotation (Line(points={{-100,
            21},{-100,28},{-74,28},{-74,80},{-168,80},{-168,72}}, color={0,0,
            127}));
    connect(constantVoltage.n, ground.p) annotation (Line(points={{-220,-14},{
            -220,-18},{-220,-18},{-220,-22}}, color={0,0,255}));
    connect(constantVoltage.p, chopperStepDown.p1) annotation (Line(points={{
            -220,6},{-180,6},{-180,12},{-138,12}}, color={0,0,255}));
    connect(emf.p, resistor.n) annotation (Line(points={{-34,0},{-32,0},{-32,10},
            {-62,10}}, color={0,0,255}));
    annotation (
      Diagram(coordinateSystem(preserveAspectRatio = true, extent={{-300,-100},
              {180,100}})),
      Icon(coordinateSystem(preserveAspectRatio = true, extent={{-300,-100},{
              180,100}})),
      experiment(
        StopTime=3080,
        __Dymola_NumberOfIntervals=5000,
        Tolerance=1e-06,
        __Dymola_Algorithm="Dassl"));
  end Test_Profile;

  model Battery_Profile
      parameter Modelica.SIunits.Frequency f=10000 "Switching frequency";

    Electrical_Components.transfo_controlled
      chopperStepDown
      annotation (Placement(transformation(extent={{-138,-8},{-118,12}})));
    Modelica.Mechanics.Translational.Components.IdealRollingWheel WheelGoupil1(radius=
          0.289)
      annotation (Placement(transformation(extent={{60,-20},{80,0}})));
    Modelica.Mechanics.Rotational.Components.LossyGear ReducerAndDifferential1(lossTable=
         [0,0.88,0.88,0,0], ratio=14.87)
      annotation (Placement(transformation(extent={{22,-20},{42,0}})));
    Mechanical_Components.Goupil goupil1(v_init=3.8)
      annotation (Placement(transformation(extent={{90,-18},{116,8}})));
    Modelica.Electrical.Analog.Basic.Resistor resistor(R=25e-3, useHeatPort=
          false)
      annotation (Placement(transformation(extent={{-82,0},{-62,20}})));
    Modelica.Electrical.Analog.Basic.EMF emf(k=0.12)
      annotation (Placement(transformation(extent={{-44,-20},{-24,0}})));
    Modelica.Mechanics.Rotational.Components.Inertia inertia(J=0.0238)
      annotation (Placement(transformation(extent={{-12,-20},{8,0}})));
    Modelica.Mechanics.Translational.Sensors.AccSensor accSensor
      annotation (Placement(transformation(extent={{90,8},{110,28}})));
    Modelica.Electrical.Analog.Basic.Ground ground annotation (Placement(
          transformation(extent={{-230,-42},{-210,-22}})));
    Modelica.Electrical.Analog.Basic.Ground ground1
                                                   annotation (Placement(
          transformation(extent={{-44,-52},{-24,-32}})));
    Modelica.Blocks.Nonlinear.Limiter limiter(uMax=1, uMin=-1)
      annotation (Placement(transformation(extent={{-6,-6},{6,6}},
          rotation=0,
          origin={-112,64})));
    Modelica.Electrical.Analog.Sensors.CurrentSensor currentSensor
      annotation (Placement(transformation(extent={{-110,20},{-90,0}})));
    Modelica.Thermal.HeatTransfer.Sources.FixedTemperature fixedTemperature(T=303.15)
      annotation (Placement(transformation(extent={{-284,-16},{-264,4}})));
    Modelica.Blocks.Sources.CombiTimeTable SpeedTable(
      fileName=
          "C:/Users/mbudinge/Documents/GitHub/EVpowertrain/notebook/modelica/Velocity_Cycle.txt",
      tableName="tab1",
      tableOnFile=true,
      extrapolation=Modelica.Blocks.Types.Extrapolation.Periodic)                                                                                                                       annotation (
      Placement(visible = true, transformation(origin={-276,64},   extent = {{-10, -10}, {10, 10}}, rotation = 0)));

    Modelica.Blocks.Math.Gain Convert1(k=1/3.6)     annotation (
      Placement(visible = true, transformation(origin={-246,64},   extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    Modelica.Blocks.Math.Feedback feedbackSpeed annotation (Placement(visible=
            true, transformation(
          origin={-222,64},
          extent={{-10,10},{10,-10}},
          rotation=0)));
    Modelica.Blocks.Math.Gain GainSpeed(k=100) annotation (Placement(visible=
            true, transformation(
          origin={-196,64},
          extent={{-10,-10},{10,10}},
          rotation=0)));
    Modelica.Blocks.Math.Gain Convert2(k=1/1000)     annotation (
      Placement(visible = true, transformation(origin={143,-49},   extent={{-11,-11},
              {11,11}},                                                                             rotation = -90)));
    Modelica.Blocks.Math.Gain gain1(k=0.5/100)   annotation (
      Placement(visible = true, transformation(origin={102,-32},    extent = {{-10, -10}, {10, 10}}, rotation = 90)));
    Modelica.Blocks.Tables.CombiTable1D SlopeTable1D(
      fileName=
          "C:/Users/mbudinge/Documents/GitHub/EVpowertrain/notebook/modelica/Slope_Cycle.txt",
      tableName="tab1",
      tableOnFile=true,
      extrapolation=Modelica.Blocks.Types.Extrapolation.Periodic)                                                                                                    annotation (
      Placement(visible = true, transformation(origin={102,-62},   extent = {{-10, -10}, {10, 10}}, rotation = 90)));

    Modelica.Mechanics.Translational.Sensors.PositionSensor positionSensor1
                                                                           annotation (
      Placement(visible = true, transformation(origin={132,38},   extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    Modelica.Mechanics.Translational.Sensors.SpeedSensor speedSensor annotation (
      Placement(visible = true, transformation(origin={60,38},     extent = {{10, -10}, {-10, 10}}, rotation = 0)));
    Modelica.Blocks.Math.Feedback feedbackCurrent annotation (Placement(visible=
           true, transformation(
          origin={-168,64},
          extent={{-10,10},{10,-10}},
          rotation=0)));
    Modelica.Blocks.Math.Gain GainI(k=100) annotation (Placement(visible=true,
          transformation(
          origin={-140,64},
          extent={{-10,-10},{10,10}},
          rotation=0)));
    Storage_Components.ModulePack modulePack(
      nombre_parallele=2,
      nombre_serie=15,
      Tinit(displayUnit="degC") = 303.15)
      annotation (Placement(transformation(extent={{-252,-20},{-220,0}})));
  equation
    connect(goupil1.flange_a, WheelGoupil1.flangeT) annotation (Line(points={{90,-8.9},
            {88,-8.9},{88,-10},{80,-10}},            color={0,127,0}));
    connect(ReducerAndDifferential1.flange_b, WheelGoupil1.flangeR)
      annotation (Line(points={{42,-10},{60,-10}},
                                                 color={0,0,0}));
    connect(inertia.flange_a, emf.flange)
      annotation (Line(points={{-12,-10},{-24,-10}},
                                                color={0,0,0}));
    connect(inertia.flange_b, ReducerAndDifferential1.flange_a)
      annotation (Line(points={{8,-10},{22,-10}},color={0,0,0}));
    connect(accSensor.flange, goupil1.flange_a)
      annotation (Line(points={{90,18},{90,-8.9}},   color={0,127,0}));
    connect(chopperStepDown.n2, emf.n) annotation (Line(points={{-118,-8},{-120,
            -8},{-120,-20},{-34,-20}},
                                     color={0,0,255}));
    connect(ground1.p, emf.n)
      annotation (Line(points={{-34,-32},{-34,-20}},
                                                   color={0,0,255}));
    connect(currentSensor.p, chopperStepDown.p2)
      annotation (Line(points={{-110,10},{-120,10},{-120,12},{-118,12}},
                                                     color={0,0,255}));
    connect(ground.p, chopperStepDown.n1)
      annotation (Line(points={{-220,-22},{-138,-22},{-138,-8}},
                                                             color={0,0,255}));
    connect(SpeedTable.y[1],Convert1. u) annotation (
      Line(points={{-265,64},{-258,64}},    color = {0, 0, 127}));
    connect(SlopeTable1D.y[1], gain1.u)
      annotation (Line(points={{102,-51},{102,-44}}, color={0,0,127}));
    connect(gain1.y, goupil1.Slope) annotation (Line(points={{102,-21},{102,
            -14.88},{103,-14.88}}, color={0,0,127}));
    connect(Convert2.y, SlopeTable1D.u[1]) annotation (Line(points={{143,-61.1},
            {143,-80},{102,-80},{102,-74}}, color={0,0,127}));
    connect(positionSensor1.flange, accSensor.flange)
      annotation (Line(points={{122,38},{90,38},{90,18}}, color={0,127,0}));
    connect(accSensor.flange, speedSensor.flange)
      annotation (Line(points={{90,18},{90,38},{70,38}}, color={0,127,0}));
    connect(positionSensor1.s, Convert2.u) annotation (Line(points={{143,38},{
            144,38},{144,-35.8},{143,-35.8}}, color={0,0,127}));
    connect(feedbackSpeed.y, GainSpeed.u)
      annotation (Line(points={{-213,64},{-208,64}}, color={0,0,127}));
    connect(Convert1.y, feedbackSpeed.u1)
      annotation (Line(points={{-235,64},{-230,64}}, color={0,0,127}));
    connect(speedSensor.v, feedbackSpeed.u2) annotation (Line(points={{49,38},{
            22,38},{22,86},{-222,86},{-222,72}}, color={0,0,127}));
    connect(resistor.p, currentSensor.n)
      annotation (Line(points={{-82,10},{-90,10}}, color={0,0,255}));
    connect(feedbackCurrent.u1, GainSpeed.y)
      annotation (Line(points={{-176,64},{-185,64}}, color={0,0,127}));
    connect(GainI.u, feedbackCurrent.y)
      annotation (Line(points={{-152,64},{-159,64}}, color={0,0,127}));
    connect(limiter.u, GainI.y) annotation (Line(points={{-119.2,64},{-123.6,64},
            {-123.6,64},{-129,64}}, color={0,0,127}));
    connect(limiter.y, chopperStepDown.alpha) annotation (Line(points={{-105.4,
            64},{-100,64},{-100,34},{-128,34},{-128,10.6}}, color={0,0,127}));
    connect(currentSensor.i, feedbackCurrent.u2) annotation (Line(points={{-100,
            21},{-100,28},{-74,28},{-74,80},{-168,80},{-168,72}}, color={0,0,
            127}));
    connect(resistor.n, emf.p) annotation (Line(points={{-62,10},{-48,10},{-48,
            8},{-34,8},{-34,0}}, color={0,0,255}));
    connect(ground.p, modulePack.pin_n) annotation (Line(points={{-220,-22},{
            -222,-22},{-222,0.2},{-231,0.2}}, color={0,0,255}));
    connect(chopperStepDown.p1, modulePack.pin_p) annotation (Line(points={{
            -138,12},{-238,12},{-238,0}}, color={0,0,255}));
    connect(modulePack.port_a, fixedTemperature.port) annotation (Line(points={
            {-246,-10},{-254,-10},{-254,-6},{-264,-6}}, color={191,0,0}));
    annotation (
      Diagram(coordinateSystem(preserveAspectRatio = true, extent={{-300,-100},
              {180,100}})),
      Icon(coordinateSystem(preserveAspectRatio = true, extent={{-300,-100},{
              180,100}})),
      experiment(
        StopTime=30800,
        __Dymola_NumberOfIntervals=50000,
        Tolerance=1e-06,
        __Dymola_Algorithm="Dassl"));
  end Battery_Profile;

  model TestBattery
    Storage_Components.Cellbis cellbis
      annotation (Placement(transformation(extent={{-42,-26},{2,18}})));
    Modelica.Electrical.Analog.Basic.Ground ground
      annotation (Placement(transformation(extent={{-30,-58},{-10,-38}})));
    Modelica.Electrical.Analog.Sources.StepCurrent stepCurrent(I=52.3)
      annotation (Placement(transformation(
          extent={{-10,-10},{10,10}},
          rotation=270,
          origin={30,0})));
    Modelica.Thermal.HeatTransfer.Sources.FixedHeatFlow fixedHeatFlow(Q_flow=0)
      annotation (Placement(transformation(extent={{-78,-28},{-58,-8}})));
  equation
    connect(ground.p, cellbis.pin_n)
      annotation (Line(points={{-20,-38},{-20,-25.12}}, color={0,0,255}));
    connect(stepCurrent.p, cellbis.pin_p) annotation (Line(points={{30,10},{32,
            10},{32,17.56},{-20.44,17.56}}, color={0,0,255}));
    connect(stepCurrent.n, cellbis.pin_n) annotation (Line(points={{30,-10},{30,
            -25.12},{-20,-25.12}}, color={0,0,255}));
    connect(fixedHeatFlow.port, cellbis.port_heat) annotation (Line(points={{
            -58,-18},{-50,-18},{-50,-17.2},{-42,-17.2}}, color={191,0,0}));
    annotation (Icon(coordinateSystem(preserveAspectRatio=false)), Diagram(
          coordinateSystem(preserveAspectRatio=false)));
  end TestBattery;

  model TestBatteryPulse
    Storage_Components.Cell cellbis(SOC=0.5)
      annotation (Placement(transformation(extent={{-42,-26},{2,18}})));
    Modelica.Electrical.Analog.Basic.Ground ground
      annotation (Placement(transformation(extent={{-30,-58},{-10,-38}})));
    Modelica.Electrical.Analog.Sources.StepCurrent stepCurrent(
      I=-25,
      offset=25,
      startTime=400) annotation (Placement(transformation(
          extent={{-10,-10},{10,10}},
          rotation=90,
          origin={32,0})));
    Modelica.Electrical.Analog.Sensors.PotentialSensor potentialSensor
      annotation (Placement(transformation(extent={{50,8},{70,28}})));
  equation
    connect(ground.p, cellbis.pin_n)
      annotation (Line(points={{-20,-38},{-20,-25.12}}, color={0,0,255}));
    connect(stepCurrent.n, cellbis.pin_p) annotation (Line(points={{32,10},{32,
            17.56},{-20.44,17.56}}, color={0,0,255}));
    connect(stepCurrent.p, cellbis.pin_n) annotation (Line(points={{32,-10},{32,
            -25.12},{-20,-25.12}}, color={0,0,255}));
    connect(potentialSensor.p, stepCurrent.n) annotation (Line(points={{50,18},
            {40,18},{40,10},{32,10}}, color={0,0,255}));
    annotation (Icon(coordinateSystem(preserveAspectRatio=false)), Diagram(
          coordinateSystem(preserveAspectRatio=false)));
  end TestBatteryPulse;

  model Battery_Profile_ThermalPlate
      parameter Modelica.SIunits.Frequency f=10000 "Switching frequency";

    Electrical_Components.transfo_controlled
      chopperStepDown
      annotation (Placement(transformation(extent={{-138,-8},{-118,12}})));
    Modelica.Mechanics.Translational.Components.IdealRollingWheel WheelGoupil1(radius=
          0.289)
      annotation (Placement(transformation(extent={{90,-22},{110,-2}})));
    Modelica.Mechanics.Rotational.Components.IdealGear ReducerAndDifferential1(ratio=
          14.87*0.6)
      annotation (Placement(transformation(extent={{30,-22},{50,-2}})));
    Mechanical_Components.Goupil goupil1
      annotation (Placement(transformation(extent={{120,-20},{146,6}})));
    Modelica.Electrical.Analog.Basic.Resistor resistor(R=25e-3, useHeatPort=
          false)
      annotation (Placement(transformation(extent={{-82,0},{-62,20}})));
    Modelica.Electrical.Analog.Basic.EMF emf(k=0.12)
      annotation (Placement(transformation(extent={{-44,-20},{-24,0}})));
    Modelica.Mechanics.Rotational.Components.Inertia inertia(J=0.0238)
      annotation (Placement(transformation(extent={{0,-22},{20,-2}})));
    Modelica.Mechanics.Translational.Sensors.AccSensor accSensor
      annotation (Placement(transformation(extent={{120,6},{140,26}})));
    Modelica.Electrical.Analog.Basic.Ground ground annotation (Placement(
          transformation(extent={{-230,-42},{-210,-22}})));
    Modelica.Electrical.Analog.Basic.Ground ground1
                                                   annotation (Placement(
          transformation(extent={{-44,-52},{-24,-32}})));
    Modelica.Blocks.Nonlinear.Limiter limiterAlpha(uMax=1, uMin=-1) annotation (
       Placement(transformation(
          extent={{-6,-6},{6,6}},
          rotation=0,
          origin={-110,44})));
    Modelica.Electrical.Analog.Sensors.CurrentSensor currentSensor
      annotation (Placement(transformation(extent={{-110,20},{-90,0}})));
    Modelica.Thermal.HeatTransfer.Sources.FixedTemperature fixedTemperature(T=303.15)
      annotation (Placement(transformation(extent={{-310,-40},{-290,-20}})));
    Modelica.Blocks.Sources.CombiTimeTable SpeedTable(
      fileName=
          "C:/Users/mbudinge/Documents/GitHub/EVpowertrain/notebook/modelica/Velocity_Cycle.txt",
      tableName="tab1",
      tableOnFile=true,
      extrapolation=Modelica.Blocks.Types.Extrapolation.Periodic)                                                                                                                       annotation (
      Placement(visible = true, transformation(origin={-308,44},   extent = {{-10, -10}, {10, 10}}, rotation = 0)));

    Modelica.Blocks.Math.Gain Convert1(k=1/3.6)     annotation (
      Placement(visible = true, transformation(origin={-278,44},   extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    Modelica.Blocks.Math.Feedback feedbackSpeed annotation (Placement(visible=
            true, transformation(
          origin={-254,44},
          extent={{-10,10},{10,-10}},
          rotation=0)));
    Modelica.Blocks.Math.Gain GainSpeed(k=1000)
                                               annotation (Placement(visible=
            true, transformation(
          origin={-228,44},
          extent={{-10,-10},{10,10}},
          rotation=0)));
    Modelica.Blocks.Math.Gain Convert2(k=1/1000)     annotation (
      Placement(visible = true, transformation(origin={173,-51},   extent={{-11,-11},
              {11,11}},                                                                             rotation = -90)));
    Modelica.Blocks.Nonlinear.Limiter
                              limiter1(uMax=0.10)
                                                 annotation (
      Placement(visible = true, transformation(origin={132,-32},    extent={{-8,-8},
              {8,8}},                                                                                rotation = 90)));
    Modelica.Blocks.Tables.CombiTable1D SlopeTable1D(
      fileName=
          "C:/Users/mbudinge/Documents/GitHub/EVpowertrain/notebook/modelica/Slope_Cycle.txt",
      tableName="tab1",
      tableOnFile=true,
      extrapolation=Modelica.Blocks.Types.Extrapolation.Periodic)                                                                                                    annotation (
      Placement(visible = true, transformation(origin={132,-82},   extent = {{-10, -10}, {10, 10}}, rotation = 90)));

    Modelica.Mechanics.Translational.Sensors.PositionSensor positionSensor1
                                                                           annotation (
      Placement(visible = true, transformation(origin={162,36},   extent = {{-10, -10}, {10, 10}}, rotation = 0)));
    Modelica.Mechanics.Translational.Sensors.SpeedSensor speedSensor annotation (
      Placement(visible = true, transformation(origin={90,36},     extent = {{10, -10}, {-10, 10}}, rotation = 0)));
    Modelica.Blocks.Math.Feedback feedbackCurrent annotation (Placement(visible=
           true, transformation(
          origin={-168,44},
          extent={{-10,10},{10,-10}},
          rotation=0)));
    Modelica.Blocks.Math.Gain GainI(k=100) annotation (Placement(visible=true,
          transformation(
          origin={-140,44},
          extent={{-10,-10},{10,10}},
          rotation=0)));
    Storage_Components.ModulePack modulePack(
      nombre_parallele=2,
      nombre_serie=15,
      Tinit(displayUnit="degC") = 303.15)
      annotation (Placement(transformation(extent={{-262,-26},{-220,0}})));
    Modelica.Thermal.HeatTransfer.Components.ThermalResistor thermalResistor(R=1/5/1)
      annotation (Placement(transformation(extent={{-280,-40},{-260,-20}})));
    Modelica.Blocks.Math.Gain GainSlope(k=0.5/100) annotation (Placement(
          visible=true, transformation(
          origin={132,-56},
          extent={{-8,-8},{8,8}},
          rotation=90)));
    Modelica.Blocks.Nonlinear.Limiter limiterCurrent(uMax=200, uMin=-200)
      annotation (Placement(transformation(
          extent={{-6,-6},{6,6}},
          rotation=0,
          origin={-198,44})));
  equation
    connect(goupil1.flange_a, WheelGoupil1.flangeT) annotation (Line(points={{120,
            -10.9},{118,-10.9},{118,-12},{110,-12}}, color={0,127,0}));
    connect(accSensor.flange, goupil1.flange_a)
      annotation (Line(points={{120,16},{120,-10.9}},color={0,127,0}));
    connect(chopperStepDown.n2, emf.n) annotation (Line(points={{-118,-8},{-116,
            -8},{-116,-20},{-34,-20}},
                                     color={0,0,255}));
    connect(ground1.p, emf.n)
      annotation (Line(points={{-34,-32},{-34,-20}},
                                                   color={0,0,255}));
    connect(currentSensor.p, chopperStepDown.p2)
      annotation (Line(points={{-110,10},{-120,10},{-120,12},{-118,12}},
                                                     color={0,0,255}));
    connect(ground.p, chopperStepDown.n1)
      annotation (Line(points={{-220,-22},{-138,-22},{-138,-8}},
                                                             color={0,0,255}));
    connect(SpeedTable.y[1],Convert1. u) annotation (
      Line(points={{-297,44},{-290,44}},    color = {0, 0, 127}));
    connect(limiter1.y, goupil1.Slope) annotation (Line(points={{132,-23.2},{
            132,-16.88},{133,-16.88}}, color={0,0,127}));
    connect(Convert2.y, SlopeTable1D.u[1]) annotation (Line(points={{173,-63.1},
            {173,-98},{132,-98},{132,-94}}, color={0,0,127}));
    connect(positionSensor1.flange, accSensor.flange)
      annotation (Line(points={{152,36},{120,36},{120,16}},
                                                          color={0,127,0}));
    connect(accSensor.flange, speedSensor.flange)
      annotation (Line(points={{120,16},{120,36},{100,36}},
                                                         color={0,127,0}));
    connect(positionSensor1.s, Convert2.u) annotation (Line(points={{173,36},{
            174,36},{174,-37.8},{173,-37.8}}, color={0,0,127}));
    connect(feedbackSpeed.y, GainSpeed.u)
      annotation (Line(points={{-245,44},{-240,44}}, color={0,0,127}));
    connect(Convert1.y, feedbackSpeed.u1)
      annotation (Line(points={{-267,44},{-262,44}}, color={0,0,127}));
    connect(speedSensor.v, feedbackSpeed.u2) annotation (Line(points={{79,36},{
            -10,36},{-10,66},{-254,66},{-254,52}},
                                                 color={0,0,127}));
    connect(resistor.p, currentSensor.n)
      annotation (Line(points={{-82,10},{-90,10}}, color={0,0,255}));
    connect(GainI.u, feedbackCurrent.y)
      annotation (Line(points={{-152,44},{-159,44}}, color={0,0,127}));
    connect(limiterAlpha.u, GainI.y)
      annotation (Line(points={{-117.2,44},{-129,44}}, color={0,0,127}));
    connect(limiterAlpha.y, chopperStepDown.alpha) annotation (Line(points={{-103.4,
            44},{-100,44},{-100,34},{-128,34},{-128,10.6}},        color={0,0,
            127}));
    connect(currentSensor.i, feedbackCurrent.u2) annotation (Line(points={{-100,21},
            {-100,30},{-68,30},{-68,58},{-168,58},{-168,52}},     color={0,0,
            127}));
    connect(ground.p, modulePack.pin_n) annotation (Line(points={{-220,-22},{
            -222,-22},{-222,0.26},{-234.438,0.26}},
                                              color={0,0,255}));
    connect(chopperStepDown.p1, modulePack.pin_p) annotation (Line(points={{-138,12},
            {-243.625,12},{-243.625,0}},  color={0,0,255}));
    connect(thermalResistor.port_b, modulePack.port_a) annotation (Line(points={{-260,
            -30},{-248,-30},{-248,-13},{-254.125,-13}},    color={191,0,0}));
    connect(thermalResistor.port_a, fixedTemperature.port)
      annotation (Line(points={{-280,-30},{-290,-30}}, color={191,0,0}));
    connect(resistor.n, emf.p)
      annotation (Line(points={{-62,10},{-34,10},{-34,0}}, color={0,0,255}));
    connect(GainSlope.y, limiter1.u)
      annotation (Line(points={{132,-47.2},{132,-41.6}}, color={0,0,127}));
    connect(GainSlope.u, SlopeTable1D.y[1])
      annotation (Line(points={{132,-65.6},{132,-71}}, color={0,0,127}));
    connect(inertia.flange_b, ReducerAndDifferential1.flange_a)
      annotation (Line(points={{20,-12},{30,-12}}, color={0,0,0}));
    connect(ReducerAndDifferential1.flange_b, WheelGoupil1.flangeR)
      annotation (Line(points={{50,-12},{90,-12}}, color={0,0,0}));
    connect(inertia.flange_a, emf.flange) annotation (Line(points={{0,-12},{-14,
            -12},{-14,-10},{-24,-10}}, color={0,0,0}));
    connect(limiterCurrent.y, feedbackCurrent.u1)
      annotation (Line(points={{-191.4,44},{-176,44}}, color={0,0,127}));
    connect(limiterCurrent.u, GainSpeed.y)
      annotation (Line(points={{-205.2,44},{-217,44}}, color={0,0,127}));
    annotation (
      Diagram(coordinateSystem(preserveAspectRatio = true, extent={{-320,-100},
              {200,100}})),
      Icon(coordinateSystem(preserveAspectRatio = true, extent={{-320,-100},{
              200,100}})),
      experiment(
        StopTime=30800,
        __Dymola_NumberOfIntervals=50000,
        Tolerance=1e-06,
        __Dymola_Algorithm="Dassl"));
  end Battery_Profile_ThermalPlate;

  annotation (
    uses(Modelica(version="3.2.3")));
end Goupil_Thermal;
